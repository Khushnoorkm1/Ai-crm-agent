# AI CRM v3 — Antigravity Agent Rules
# Path: .antigravity/rules.md

## Project
Fully-automated Node.js CRM for Indian web design agency.
Google Sheet → AI Score → Email → AI Call → WhatsApp → Google Meet
All without manual work. Telegram bot controls everything from phone.

## Agent Behavior Rules

### Before writing any code:
1. Read CLAUDE.md in project root — it has complete architecture
2. Check which service file is relevant (see services/ folder map in CLAUDE.md)
3. Never modify ./data/leads.json directly — use db.read() / db.write()
4. Never create duplicate service files — check if function already exists

### Terminal commands agent can auto-run:
```
ALLOW: npm install, npm run dev, node server.js, node -e "...", git add, git commit, git push
ALLOW: curl http://localhost:3000/*, mkdir -p, cp, mv
DENY:  rm -rf data/, rm -rf recordings/, git push --force
```

### File creation rules:
- New service → services/newService.js
- New route → add to server.js (not a new file)
- New frontend → public/newpage.html
- Never create TypeScript files — this is plain JS

### When fixing errors:
- Check .env first — most errors are missing env vars
- Check if BASE_URL is public (not localhost) for Twilio/Telegram
- Check ./data/ folder exists (auto-created but may be missing)

## Stack Quick Reference
```
Language:   JavaScript (Node.js 20, CommonJS require())
Database:   JSON file — app.locals.db.read() / db.write()
AI Model:   claude-sonnet-4-20250514
Call Voice: Polly.Aditi (Hindi female, Twilio)
Email:      Gmail SMTP via Nodemailer
WhatsApp:   Twilio sandbox (whatsapp:+14155238886)
```

## Lead Status Flow
new → contacted → interested → meeting → closed → dnc

## Business Context
- Target customers: Indian small business owners
- Service sold: Website design (starting ₹8,000)
- Language: Hinglish (Hindi + English) in all customer comms
- Call hours: 10AM–6PM IST only (Asia/Kolkata)
- Market: India (phone +91 prefix, IST timezone)
