# GitHub Copilot Instructions — AI CRM v3

## Project in one line
Node.js CRM that reads leads from Google Sheet and automatically emails, calls (with real AI conversation), WhatsApps, and books Google Meet — all triggered by adding a row in a spreadsheet.

## Critical patterns to always follow

### 1. Database access
```javascript
// Always fresh read — never store reference
const data = app.locals.db.read(); // or db.read()
data.leads.push(newItem);
app.locals.db.write(data);
```

### 2. Phone normalization
```javascript
const phone = String(raw).replace(/\D/g, "").slice(-10); // 10 digits only
const twilioTo = "+91" + phone; // Only when passing to Twilio
```

### 3. IST time check
```javascript
const ist = new Date(Date.now() + 5.5 * 60 * 60 * 1000);
const hour = ist.getUTCHours(); // 10-18 = calling hours
```

### 4. Retry wrapper for all external calls
```javascript
const { withRetry } = require("./services/retryService");
await withRetry(() => externalApi(), { maxRetries: 3, label: "Email send" });
```

### 5. Guard check before any outreach
```javascript
const { runAllGuards } = require("./services/guardService");
const guard = await runAllGuards(lead, db);
if (guard.blocked) return;
```

### 6. Telegram notification for important events
```javascript
const { notify } = require("./services/telegramBot");
await notify(`Event happened: ${lead.name}`);
```

## File responsibilities (don't mix concerns)
- `server.js` — routes only, no business logic
- `autoOrchestrator.js` — workflow sequencing only
- `guardService.js` — validation only (DNC, duplicate, hours)
- `retryService.js` — retry logic only
- `callService.js` — Twilio call management only
- `emailService.js` — email generation + sending only
- `whatsappService.js` — WhatsApp only
- `meetingService.js` — Google Calendar only
- `telegramBot.js` — Telegram commands only
- `chatbotService.js` — website chat sessions only
- `leadScoringService.js` — scoring algorithm only
- `sheetUpdateService.js` — Google Sheet writes only
- `followUpScheduler.js` — scheduled follow-ups only
- `dailyReportService.js` — daily email report only

## Language for customer-facing content
All emails, call scripts, WhatsApp messages = Hinglish (Hindi + English mix)
Example: "Namaste Rahul ji! Aapke restaurant ke liye ek professional website bahut helpful hogi."

## Lead status enum
"new" | "contacted" | "interested" | "meeting" | "closed" | "dnc"

## Never suggest
- TypeScript migration
- External database (MongoDB, PostgreSQL etc)
- React/Vue frontend
- Storing phone with +91 in DB
- Caching db.read() results
- Calling outside 10AM-6PM IST
- Skipping DNC check
