# AI CRM v3 — Ready-Made AI Prompts
# Jab bhi Cursor/Copilot/Claude se kaam karwana ho — yeh prompts copy karo

---

## Naya feature add karne ke liye

### Naya Telegram command add karo
```
Is AI CRM v3 project mein /mystats naam ka naya Telegram command add karo.
Yeh command show kare: is hafte kitne leads aaye, kitne calls hue, aur best performing city kaun si hai.
CLAUDE.md padho pehle. telegramBot.js mein handleUpdate switch statement mein add karo.
```

### Naya email template add karo
```
emailService.js mein ek naya email type "re_engagement" add karo.
Yeh un leads ke liye hai jo 30 din se inactive hain.
Hinglish mein likhna hai. generatePersonalizedEmail() function mein prompts object mein add karo.
```

### Naya dashboard card add karo
```
public/dashboard.html mein stats row mein ek naya card add karo jo "WhatsApp Reply Rate" dikhaye.
(whatsapp replies / whatsapp sent * 100)
/api/dashboard/stats endpoint bhi update karo is stat ke liye.
CLAUDE.md ki dashboard stats section dekho.
```

---

## Bug fix karne ke liye

### Email nahi ja raha
```
Is project mein email send nahi ho raha. Error yeh hai: [PASTE ERROR HERE]
CLAUDE.md padho. emailService.js aur .env ke SMTP settings check karo.
Fix karo aur test bhi karo.
```

### Call recording save nahi ho rahi
```
AI CRM v3 mein call recordings ./recordings/ mein save nahi ho rahi.
callService.js ka saveRecording() function check karo.
CLAUDE.md mein "Calling Architecture" section dekho.
Twilio auth credentials aur BASE_URL bhi check karo.
```

### Telegram bot respond nahi kar raha
```
Telegram bot /start ka respond nahi de raha.
CLAUDE.md padho. telegramBot.js + server.js mein /api/telegram/webhook route check karo.
BASE_URL correct hai? /api/telegram/setup hit kiya tha?
```

---

## Code samajhne ke liye

### Poore flow ko trace karo
```
CLAUDE.md padho. Phir explain karo: jab Google Sheet mein ek naya lead add hota hai,
step by step kya hota hai — kaun sa function call hota hai, kya save hota hai,
kaunsa message jaata hai, final tak. Code trace karo services folder mein.
```

### Service kaise kaam karta hai
```
CLAUDE.md padho. Phir guardService.js ko fully explain karo:
- runAllGuards() kya check karta hai
- DNC list kahan store hoti hai
- Call hours IST mein kaise calculate hote hain
- Duplicate check kaise hota hai
```

---

## Testing ke liye

### Saare APIs test karo
```
Is project ke liye ek test script banao: test.js naam se.
CLAUDE.md mein "API Routes" section dekho.
Sab important endpoints ko curl ya node-fetch se test karo.
Ek test lead add karo, score check karo, DNC add/remove test karo.
```

### Local testing guide
```
CLAUDE.md padho. Mujhe step by step batao kaise main locally test karun:
1. Server start kaise karu
2. Ngrok setup kaise karu
3. Email test kaise karu bina real email bheje
4. Call test kaise karu bina real Twilio call kiye
5. Dashboard kaise check karun
```

---

## Deployment ke liye

### Railway deploy
```
CLAUDE.md padho. Mujhe step by step guide do Railway.app pe deploy karne ke liye.
Konse environment variables Railway mein add karne hain? (.env se)
Kaise verify karun ki sab kuch sahi deploy hua?
```

### Production checklist
```
CLAUDE.md padho. Ek production readiness checklist banao:
- Security checks (.env, TELEGRAM_CHAT_ID, etc.)
- Performance checks
- Monitoring setup
- Backup strategy for leads.json
- Error alerting via Telegram
```

---

## New Feature Ideas ko implement karne ke liye

### Instagram lead capture
```
CLAUDE.md padho. Is CRM mein Instagram DM lead capture add karna hai.
Koi visitor Instagram pe DM kare → CRM mein add ho → automation shuru.
Instagram Graph API use karna hoga. New service file banao: services/instagramService.js
Existing autoOrchestrator.js ke pattern ko follow karo.
```

### Invoice generator
```
CLAUDE.md padho. Meeting ke baad automatically PDF invoice generate karo.
Lead ka naam, business, meeting date, website package details include karo.
Nodemailer se lead ko bhejo. New service: services/invoiceService.js
Meeting schedule hone pe autoOrchestrator.js mein trigger karo.
```

---

## Useful System Prompts for AI Chats

### Jab Copilot Chat ya Cursor Chat use karo — paste at start:
```
I'm working on AI CRM v3 project. This is a Node.js Express CRM for Indian web design agency.
Key context from CLAUDE.md:
- Database: JSON file (./data/leads.json) — always db.read() fresh
- Phone: 10 digits no +91 in DB
- Language: Hinglish for all customer content
- Call hours: 10AM-6PM IST only
- Always use retryService.withRetry() for external APIs
- Lead status: new|contacted|interested|meeting|closed|dnc
Please help me with: [YOUR QUESTION]
```

### Claude.ai mein paste karo:
```
Project: AI CRM v3 (Node.js, Express, Twilio, Claude AI, Google Calendar, Telegram)
Architecture: autoOrchestrator runs sequence: score → email → call → WhatsApp → meeting
Services: guardService, retryService, emailService, callService, whatsappService,
          meetingService, telegramBot, chatbotService, leadScoringService,
          sheetUpdateService, followUpScheduler, dailyReportService
Database: ./data/leads.json (JSON file, no external DB)
All customer comms: Hinglish. Calls: 10AM-6PM IST only.
[YOUR QUESTION]
```
