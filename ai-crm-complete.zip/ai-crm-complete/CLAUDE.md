# AI CRM v3 — Project Intelligence File
# Yeh file project root mein rakho. Har AI tool automatically padh leta hai.
# Works: Cursor (.cursorrules), Antigravity (.antigravity/rules.md), VSCode Copilot, Claude, ChatGPT

---

## Project ka ek line summary
Ek fully-automated Node.js CRM system jo Google Sheet se leads leta hai aur automatically email bhejta hai, real AI phone call karta hai, WhatsApp message karta hai, call record karta hai, aur Google Meet schedule karta hai — bina kisi manual kaam ke.

---

## Tech Stack (exact versions)

```
Runtime:     Node.js 20+ (LTS)
Framework:   Express 4.19
AI:          Anthropic Claude (claude-sonnet-4-20250514)
Calls:       Twilio Programmable Voice + Media Streams (WebSocket)
Email:       Nodemailer + Gmail SMTP
WhatsApp:    Twilio WhatsApp Sandbox API
Meetings:    Google Calendar API v3 (OAuth2)
Bot:         Telegram Bot API (native https — no library)
Database:    JSON file (./data/leads.json) — no external DB
Hosting:     Railway.app (recommended) or any Node.js host
```

---

## Folder Structure (complete)

```
ai-crm-v3/
│
├── server.js                    ← Main Express server + all routes + WebSocket
├── package.json
├── .env                         ← All API keys (NEVER commit this)
├── .gitignore
├── CLAUDE.md                    ← THIS FILE (AI context)
│
├── services/
│   ├── autoOrchestrator.js      ← BRAIN: lead aaya → score → email → call → WA → meeting
│   ├── guardService.js          ← Call hours (10AM-6PM IST), duplicate check, DNC list
│   ├── retryService.js          ← Exponential backoff retry for email/call/WA
│   ├── dailyReportService.js    ← 8AM IST daily summary email
│   ├── telegramBot.js           ← Telegram bot: phone se CRM control
│   ├── chatbotService.js        ← Website chatbot: visitor ka lead capture
│   ├── callService.js           ← Twilio calls + AI conversation + recording save
│   ├── whatsappService.js       ← Twilio WhatsApp send + incoming reply handler
│   ├── leadScoringService.js    ← AI scoring 0-100 (business type + city + notes)
│   ├── sheetUpdateService.js    ← Google Sheet webapp se 2-way sync
│   ├── followUpScheduler.js     ← Day 3/7/14 automatic follow-up sequences
│   ├── emailService.js          ← Nodemailer + Claude AI personalized Hinglish emails
│   └── meetingService.js        ← Google Calendar auto Meet + SMS + email confirm
│
├── public/
│   └── dashboard.html           ← Live dashboard (Chart.js, recordings playback, DNC)
│
├── data/                        ← Auto-created on first run
│   ├── leads.json               ← Main DB (leads, calls, emails, recordings, logs)
│   └── dnc.json                 ← Do Not Call/Contact list
│
└── recordings/                  ← Auto-created — Twilio MP3 recordings saved here
```

---

## Environment Variables (.env) — complete list

```bash
# Server
PORT=3000
BASE_URL=https://your-railway-url.com        # Public URL (ngrok for local, Railway for prod)
BASE_DOMAIN=your-railway-url.com             # Domain without https://

# Agency
AGENCY_NAME=WebPro Agency
AGENCY_PHONE=+91-9876543210
AGENCY_WEBSITE=https://yourwebsite.com

# AI
ANTHROPIC_API_KEY=sk-ant-xxxxx               # console.anthropic.com

# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_EMAIL=you@gmail.com
SMTP_PASSWORD=xxxx xxxx xxxx xxxx            # Gmail App Password (with spaces)
REPORT_EMAIL=you@gmail.com                   # Daily report jaata hai yahan

# Twilio (Calls + WhatsApp)
TWILIO_ACCOUNT_SID=ACxxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxx
TWILIO_PHONE_NUMBER=+1xxxxxxxxxx
TWILIO_WHATSAPP_NUMBER=whatsapp:+14155238886  # Sandbox number

# Google Calendar
GOOGLE_CLIENT_ID=xxxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-xxxxx
GOOGLE_REDIRECT_URI=http://localhost:3000/auth/google/callback
GOOGLE_REFRESH_TOKEN=1//xxxxx

# Google Sheet Web App
GOOGLE_SHEET_WEBAPP_URL=https://script.google.com/macros/s/XXXXX/exec

# Telegram Bot
TELEGRAM_BOT_TOKEN=1234567890:ABCdef...
TELEGRAM_CHAT_ID=987654321                   # Your personal chat ID
```

---

## Database Schema (leads.json)

```javascript
{
  leads: [{
    id:             "lead_2_1234567890",    // Unique ID
    name:           "Rahul Sharma",
    business:       "Sharma Restaurant",
    phone:          "9876543210",           // Always 10 digits, no +91
    email:          "rahul@gmail.com",
    city:           "Mumbai",
    notes:          "Interested in website",
    source:         "google_sheet",         // or "chatbot"
    status:         "new",                  // new|contacted|interested|meeting|closed|dnc
    score:          87,                     // AI score 0-100
    priority:       "HIGH",                 // HIGH|MEDIUM|LOW
    scoreTags:      ["High-value business", "Metro city"],
    rowIndex:       2,                      // Google Sheet row number
    emailSent:      "ISO timestamp",
    callOutcome:    "interested",           // interested|not_interested|call_later|no_answer
    callTranscript: [{role:"user",text:""},{role:"assistant",text:""}],
    callDuration:   120,                    // seconds
    recordingFile:  "lead_2_xxx.mp3",
    whatsappSent:   "ISO timestamp",
    meetLink:       "https://meet.google.com/xxx",
    meetingTime:    "ISO timestamp",
    lastContact:    "1/1/2026",
    createdAt:      "ISO timestamp",
  }],
  calls:        [{ leadId, leadName, phone, status, duration, time }],
  emails:       [{ leadName, email, subject, sentAt, success }],
  recordings:   [{ sessionId, recordingSid, filename, url, path, time, duration, outcome }],
  meetings:     [{ leadId, leadName, meetLink, startTime, scheduledAt }],
  transcripts:  { sessionId: { text, time, outcome } },
  failures:     [{ leadId, leadName, type, error, time }],
  logs:         { leadId: [{ time, message }] },
  dnc:          { numbers: [{phone, name, reason, addedAt}], emails: [...] },
  scheduledFollowUps: [{ key, leadId, type, scheduledAt, status }],
  reportsSent:  [{ date, stats }]
}
```

---

## Lead Status Flow

```
new → contacted → interested → meeting → closed
                                       ↘ dnc (DNC list pe add)
```

**Status kab change hota hai:**
- `new` → `contacted`: Email send hone pe ya call answered hone pe
- `contacted` → `interested`: Call pe "1" press ya "interested" bola
- `interested` → `meeting`: Google Meet schedule hone pe
- `contacted` → `closed`: "not_interested" call outcome
- Any → `dnc`: Manually blocked ya "not_interested" call pe auto-add

---

## API Routes (complete)

### Auto-processing
```
POST /api/auto/process-lead       ← Google Sheet trigger yahan POST karta hai
```

### Dashboard
```
GET  /api/dashboard/stats         ← Live stats: total, byStatus, weekCalls, conversion
GET  /api/dashboard/leads         ← All leads sorted by score
GET  /api/dashboard/recordings    ← Recordings with transcriptions
GET  /api/dashboard/failures      ← Failed operations
GET  /api/dashboard/followups     ← Pending follow-up queue
POST /api/dashboard/retry-failures ← Retry all failed ops
```

### Campaigns (manual trigger)
```
POST /api/leads/campaigns/email/start  ← All new leads ko email
POST /api/leads/campaigns/call/start   ← All eligible leads ko call
```

### Guards / DNC
```
GET  /api/guards/dnc              ← DNC list
POST /api/guards/dnc/add          ← Block: { name, phone, email, reason }
POST /api/guards/dnc/remove       ← Unblock: { phone }
```

### Twilio Webhooks (Twilio yahan POST karta hai)
```
POST /api/calling/speech/:sessionId        ← Speech recognition result
POST /api/calling/recording-done/:sessionId ← Recording available
POST /api/calling/transcription/:sessionId ← Transcription ready
POST /api/calling/call-status/:sessionId   ← Call ended/failed
```

### WhatsApp
```
POST /api/whatsapp/incoming       ← Twilio WhatsApp webhook
```

### Telegram
```
POST /api/telegram/webhook        ← Telegram updates
GET  /api/telegram/setup          ← Register webhook (run once)
POST /api/telegram/test           ← Test message bhejo
```

### Chatbot
```
POST /api/chatbot/greet           ← { sessionId } → greeting message
POST /api/chatbot/message         ← { sessionId, message } → AI reply
GET  /api/chatbot/session/:id     ← Session debug info
```

### Reports
```
POST /api/report/send-now         ← Manual daily report trigger
```

### Auth (one-time setup)
```
GET  /auth/google                 ← Google OAuth redirect
GET  /auth/google/callback        ← Token exchange
```

### Static
```
GET  /dashboard.html              ← Live dashboard UI
GET  /recordings/:filename        ← MP3 file serve
GET  /health                      ← { ok, time, callsAllowed, callTime }
GET  /                            ← Redirects to /dashboard.html
```

---

## Key Service Contracts

### autoOrchestrator.processLeadAutomatically(lead, db)
```javascript
// Input: lead object (from DB), db instance
// Flow:
// 1. runAllGuards() → DNC check, duplicate check, call hours wait
// 2. generateLeadScore() → score 0-100
// 3. sendEmailWithRetry() → Claude AI email via Gmail
// 4. sleep(5min) → makeConversationalCall() → Twilio + Claude
// 5. Handle outcome: interested/not_interested/call_later/no_answer
// 6. sendWhatsAppWithRetry() if not not_interested
// 7. autoScheduleForInterestedLead() if interested
// Returns: void (all results saved to DB + Sheet)
```

### guardService.runAllGuards(lead, db)
```javascript
// Returns: { blocked: boolean, reason?: string, type?: "dnc"|"duplicate" }
// Call hours: 10:00 AM - 6:00 PM IST (Asia/Kolkata)
// Duplicate: checks phone (last 10 digits) AND email
// DNC: checks ./data/dnc.json
```

### retryService.withRetry(fn, options)
```javascript
// options: { maxRetries=3, baseDelayMs=5000, label, onFailure }
// Exponential backoff: 5s, 10s, 20s (doubles each time)
// Returns: { success, result, attempts } or { success:false, error, attempts }
```

### callService.makeConversationalCall(lead, db)
```javascript
// Returns Promise<{ outcome, recordingUrl, transcript }>
// outcome: "interested" | "not_interested" | "call_later" | "no_answer" | "error"
// Uses Twilio Media Streams (WebSocket) for real-time audio
// AI voice: Polly.Aditi (Hindi female)
// Recording: auto-saved to ./recordings/
// Timeout: 5 minutes
```

### leadScoringService.generateLeadScore(lead)
```javascript
// Returns: { total: 0-100, tags: string[], priority: "HIGH"|"MEDIUM"|"LOW", ruleScore }
// Rule-based: business type + city tier + notes keywords
// AI-enhanced: Claude adds -20 to +20 adjustment
// HIGH = 70+, MEDIUM = 40-69, LOW = 0-39
// Score < 30 → email only, no call
```

### telegramBot.handleUpdate(update, db)
```javascript
// Handles: /start /stats /leads /run /email /call /report
//          /dnc /dnc_list /failures /retry /recordings /pipeline /help
// Security: Only TELEGRAM_CHAT_ID se messages accept karta hai
// Inline buttons bhi handle karta hai (callback_query)
```

### chatbotService.processMessage(sessionId, message, db)
```javascript
// Returns: { reply, stage, leadCaptured, sessionId }
// Stages: greeting → collecting_name → collecting_phone → collecting_email → qualifying → done
// Lead capture: name + phone milne pe DB mein add + Telegram notify + automation start
// Sessions: in-memory Map (server restart pe reset)
```

---

## Google Sheet Integration

**Sheet columns (A to P):**
```
A: Name          B: Business      C: Phone         D: Email
E: City          F: Notes         G: Status        H: Email Sent
I: Call Status   J: Call Response K: Call Recording L: WhatsApp Sent
M: Meeting Link  N: Meeting Time  O: Lead Score    P: Last Updated
```

**G to P columns CRM automatically fill karta hai** (Apps Script doPost via GOOGLE_SHEET_WEBAPP_URL)

**Trigger:** onEdit → POST /api/auto/process-lead → full automation starts

---

## Calling Architecture (WebSocket)

```
Twilio Call Initiated
       ↓
TwiML: <Connect><Stream url="wss://BASE_DOMAIN/api/calling/stream/SESSION_ID"/></Connect>
       ↓
WebSocket opens → handleMediaStream(ws, sessionId) in callService.js
       ↓
AI greeting → speakOnCall() → Polly.Aditi TTS
       ↓
Lead bolte hain → Twilio Speech Recognition → POST /api/calling/speech/SESSION_ID
       ↓
handleLeadSpeech() → Claude AI → response generate → speakOnCall()
       ↓
Claude detects outcome (OUTCOME: in response) → session.outcome set
       ↓
Call ends → finalizeCall() → DB save → orchestrator resolve
       ↓
Recording → POST /api/calling/recording-done/SESSION_ID → saveRecording() → MP3 file
```

---

## Daily Report Schedule

- Time: 8:00 AM IST (Asia/Kolkata)
- Check: Every 1 minute via setInterval
- Idempotent: lastReportDate prevents duplicate sends
- Contains: AI motivational line, calls/emails/leads stats, pipeline breakdown, top leads, failures alert

---

## Follow-up Sequences

```
Day 0:  Email + Call (autoOrchestrator)
Day 3:  Follow-up email (emailService.sendFollowUp)
Day 3:  WhatsApp reminder (2 hr after day3 email)
Day 7:  Second call attempt
Day 14: Final WhatsApp + mark as "cold"
```

---

## Error Handling Patterns

```javascript
// Retry pattern (use for all external API calls):
const result = await withRetry(() => externalApiCall(), {
  maxRetries: 3, baseDelayMs: 5000, label: "operation name"
});
if (!result.success) { /* handle failure */ }

// DB pattern (always read fresh, never cache):
const data = db.read();
// ... modify data ...
db.write(data);

// Guard pattern (always run before automation):
const guard = await runAllGuards(lead, db);
if (guard.blocked) return;
```

---

## Important Constraints & Rules

1. **Language**: All AI-generated customer content (emails, call scripts, WhatsApp) = Hinglish (Hindi + English mix)
2. **Call hours**: ONLY 10:00 AM - 6:00 PM IST. Outside hours → wait in queue
3. **Phone format**: Always store as 10-digit string (no +91 prefix in DB, add +91 only when calling)
4. **DB reads**: Always `db.read()` fresh — never cache the object (JSON file can be updated by any service)
5. **No external DB**: Everything in ./data/leads.json — no MongoDB, no Postgres needed
6. **Recording path**: ./recordings/SESSIONID_SID.mp3 — served at /recordings/filename
7. **DNC auto-add**: "not_interested" call outcome → auto-add to DNC (no more contact ever)
8. **Score threshold**: score < 30 → email only, skip call (saves Twilio credits)
9. **WebSocket**: Required for conversational calling — must use http.createServer + ws library
10. **Telegram security**: Only TELEGRAM_CHAT_ID can control the bot — reject all others

---

## Common Tasks — How to do them

### Naya service add karna:
```javascript
// 1. services/newService.js banao
// 2. server.js mein require() karo
// 3. Agar route chahiye → server.js mein app.post/get add karo
// 4. Agar orchestrator mein chahiye → autoOrchestrator.js mein import karo
```

### Naya Telegram command add karna:
```javascript
// telegramBot.js mein handleUpdate() ke switch statement mein add karo:
case "/newcommand":
  return handleNewCommand(chatId, db);
// Phir function banao: async function handleNewCommand(chatId, db) { ... }
```

### Lead status manually change karna:
```javascript
const data = db.read();
const lead = data.leads.find(l => l.phone === "9876543210");
lead.status = "meeting";
db.write(data);
```

### Naya API endpoint add karna:
```javascript
// server.js mein, server.listen() ke upar:
app.post("/api/my-new-route", async (req, res) => {
  const db = app.locals.db;
  // ... logic ...
  res.json({ success: true });
});
```

### Email template change karna:
```javascript
// emailService.js → generatePersonalizedEmail() → prompts object
// type: "cold" | "followup" | "meeting_confirm"
```

### Call script change karna:
```javascript
// callService.js → generateCallScript() → systemPrompt string
// Hinglish mein likho, 60 sec se kam words
```

---

## Debugging Tips

| Problem | Kahan dekho |
|---------|------------|
| Server start nahi ho raha | .env mein PORT set hai? All require() files exist? |
| Email nahi ja raha | SMTP_PASSWORD correct? Gmail 2FA on? App password used? |
| Call nahi ho rahi | Twilio India enabled? BASE_URL public hai (not localhost)? |
| Recording save nahi | ./recordings/ folder exist karta hai? TWILIO_AUTH_TOKEN correct? |
| Telegram response nahi | /api/telegram/setup hit kiya? BOT_TOKEN correct? |
| Sheet update nahi | GOOGLE_SHEET_WEBAPP_URL set hai? Apps Script deployed as web app? |
| Meeting schedule nahi | GOOGLE_REFRESH_TOKEN valid hai? /auth/google se refresh karo |
| Chatbot lead capture nahi | name + phone dono collect hue? telegramBot import correct? |

---

## What NOT to do

- `data.leads` ko cache mat karo — har access pe `db.read()` karo
- `.env` file GitHub pe push mat karo
- `recordings/` folder delete mat karo (recordings wahan hain)
- `data/leads.json` directly edit mat karo production mein
- Twilio webhook URLs mein `localhost` mat use karo — public URL chahiye
- `TELEGRAM_CHAT_ID` check remove mat karo — security ke liye hai
- Score < 30 wale leads ko force call mat karo — orchestrator intentionally skip karta hai
