# AI CRM v3

> Google Sheet mein lead daalo → AI automatically email, call, WhatsApp, aur Google Meet karta hai

## Quick Start

```bash
npm install
cp .env.example .env   # Fill in your API keys
node server.js
# Open: http://localhost:3000/dashboard.html
```

## What it does

1. **Google Sheet → Lead** — Visitor ya sales Sheet mein lead add karta hai
2. **AI Score** — Claude lead ko 0-100 score karta hai (business type, city, notes)
3. **Hinglish Email** — Personalized email Claude se generate hokar Gmail se jaati hai
4. **AI Phone Call** — Twilio real call karta hai, Claude real-time conversation karta hai, recording save hoti hai
5. **WhatsApp** — Call ke baad automatic WA message
6. **Google Meet** — Interested lead ke liye auto-schedule, email invite, SMS
7. **Telegram Control** — Phone se `/run`, `/stats`, `/leads` — poora CRM control
8. **Website Chatbot** — Visitor website pe aaye → naam/phone lo → CRM mein add
9. **Daily Report** — 8AM IST pe email summary

## AI Tool Context Files

| File | Tool |
|------|------|
| `CLAUDE.md` | Claude, ChatGPT, all AI |
| `.cursorrules` | Cursor IDE |
| `.antigravity/rules.md` | Antigravity |
| `.github/copilot-instructions.md` | GitHub Copilot |
| `.vscode/settings.json` | VSCode |
| `types.js` | IntelliSense (all tools) |
| `jsconfig.json` | VSCode type checking |
| `AI_PROMPTS.md` | Ready-made prompts |

## Full Documentation

See **[CLAUDE.md](./CLAUDE.md)** — complete architecture, all APIs, service contracts, database schema, debugging guide.

## Tech Stack

- Node.js 20 + Express 4
- Anthropic Claude (`claude-sonnet-4-20250514`)
- Twilio (Calls + WhatsApp)
- Nodemailer + Gmail SMTP
- Google Calendar API
- Telegram Bot API
- JSON file database (no external DB needed)

## Setup

See [CLAUDE.md → Environment Variables](./CLAUDE.md#environment-variables) for all required keys.

Minimum to get started (email only):
```
ANTHROPIC_API_KEY=...
SMTP_EMAIL=...
SMTP_PASSWORD=...   # Gmail App Password
PORT=3000
BASE_URL=http://localhost:3000
```
