// ============================================================
// GOOGLE APPS SCRIPT v2 — Full Auto Mode
// Sheet mein lead daalo → sab kuch automatic ho jaata hai
// Extensions → Apps Script → Paste → Save → Run setupTriggers
// ============================================================

const CRM_URL   = "https://YOUR-SERVER-URL.com"; // apna Railway/Render URL
const SHEET_NAME = "Leads";

// ── Column positions (0-indexed) ─────────────────────────────
const C = {
  NAME:           0,   // A
  BUSINESS:       1,   // B
  PHONE:          2,   // C
  EMAIL:          3,   // D
  CITY:           4,   // E
  NOTES:          5,   // F
  STATUS:         6,   // G  ← CRM yahan likhta hai
  EMAIL_SENT:     7,   // H  ← "Yes / timestamp"
  CALL_STATUS:    8,   // I  ← "Answered / No Answer / Busy"
  CALL_RESPONSE:  9,   // J  ← "Interested / Not Interested / Call Later"
  CALL_RECORDING: 10,  // K  ← recording URL
  WHATSAPP_SENT:  11,  // L  ← "Yes / timestamp"
  MEETING_LINK:   12,  // M  ← Google Meet URL
  MEETING_TIME:   13,  // N  ← scheduled time
  LEAD_SCORE:     14,  // O  ← AI score 0-100
  LAST_UPDATED:   15,  // P  ← auto timestamp
};

// ── 1. onEdit trigger — naya row add hote hi automation shuru ─
function onEdit(e) {
  const sheet = e.source.getActiveSheet();
  if (sheet.getName() !== SHEET_NAME) return;

  const row  = e.range.getRow();
  const col  = e.range.getColumn();
  if (row <= 1) return; // header skip

  const nameCell = sheet.getRange(row, C.NAME + 1).getValue();
  if (!nameCell) return;

  // Sirf jab Name/Phone/Email column edit ho tab trigger karo
  if (col <= 5) {
    Utilities.sleep(500); // debounce
    processNewLead(sheet, row);
  }
}

// ── 2. Process a new lead — full automation ──────────────────
function processNewLead(sheet, row) {
  const data    = sheet.getRange(row, 1, 1, 6).getValues()[0];
  const [name, business, phone, email, city, notes] = data;
  if (!name || !phone) return;

  const lead = {
    id:       `lead_${row}_${Date.now()}`,
    name, business,
    phone:    String(phone).replace(/\D/g, "").slice(-10),
    email, city, notes,
    rowIndex: row,
    sheetName: SHEET_NAME,
  };

  // Status update
  sheet.getRange(row, C.STATUS + 1).setValue("Processing...");
  sheet.getRange(row, C.LAST_UPDATED + 1).setValue(new Date().toLocaleString("hi-IN"));

  // Backend ko bhejo — woh sab handle karega
  try {
    const resp = UrlFetchApp.fetch(`${CRM_URL}/api/auto/process-lead`, {
      method:      "post",
      contentType: "application/json",
      payload:     JSON.stringify(lead),
      muteHttpExceptions: true,
    });
    const result = JSON.parse(resp.getContentText());
    sheet.getRange(row, C.STATUS + 1).setValue(result.status || "Queued");
    sheet.getRange(row, C.LEAD_SCORE + 1).setValue(result.leadScore || "");
  } catch (err) {
    sheet.getRange(row, C.STATUS + 1).setValue("Error: " + err.message);
  }
}

// ── 3. Sheet updater — CRM backend yeh call karta hai ────────
// POST /api/sheet/update  { rowIndex, field, value }
function updateSheetFromCRM(rowIndex, field, value) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const colMap = {
    status:         C.STATUS + 1,
    emailSent:      C.EMAIL_SENT + 1,
    callStatus:     C.CALL_STATUS + 1,
    callResponse:   C.CALL_RESPONSE + 1,
    callRecording:  C.CALL_RECORDING + 1,
    whatsappSent:   C.WHATSAPP_SENT + 1,
    meetingLink:    C.MEETING_LINK + 1,
    meetingTime:    C.MEETING_TIME + 1,
    leadScore:      C.LEAD_SCORE + 1,
    lastUpdated:    C.LAST_UPDATED + 1,
  };
  if (colMap[field]) {
    sheet.getRange(rowIndex, colMap[field]).setValue(value);
    sheet.getRange(rowIndex, C.LAST_UPDATED + 1).setValue(new Date().toLocaleString("hi-IN"));
  }
}

// ── 4. Web App endpoint — CRM backend sheet update ke liye ───
// Deploy > New Deployment > Web App > Anyone can access
function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const { rowIndex, updates } = body;

    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
    Object.entries(updates).forEach(([field, value]) => {
      updateSheetFromCRM(rowIndex, field, value);
    });
    return ContentService.createTextOutput(JSON.stringify({ success: true }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ error: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ── 5. Manual: Process all unprocessed leads ─────────────────
function processAllLeads() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const data  = sheet.getDataRange().getValues();
  let count   = 0;

  for (let i = 1; i < data.length; i++) {
    const row    = data[i];
    const status = row[C.STATUS];
    if (row[C.NAME] && (!status || status === "" || status === "new")) {
      processNewLead(sheet, i + 1);
      count++;
      Utilities.sleep(1000); // rate limit
    }
  }
  SpreadsheetApp.getUi().alert(`✅ ${count} leads queued for processing!`);
}

// ── 6. Add header row if missing ─────────────────────────────
function setupHeaders() {
  const sheet   = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME)
                  || SpreadsheetApp.getActiveSpreadsheet().insertSheet(SHEET_NAME);
  const headers = ["Name","Business","Phone","Email","City","Notes",
                   "Status","Email Sent","Call Status","Call Response",
                   "Call Recording","WhatsApp Sent","Meeting Link","Meeting Time",
                   "Lead Score","Last Updated"];
  sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  sheet.getRange(1, 1, 1, headers.length)
    .setBackground("#1a1a2e").setFontColor("#fff").setFontWeight("bold");
  sheet.setFrozenRows(1);
  SpreadsheetApp.getUi().alert("✅ Headers setup complete!");
}

// ── 7. Triggers setup ────────────────────────────────────────
function setupTriggers() {
  ScriptApp.getProjectTriggers().forEach(t => ScriptApp.deleteTrigger(t));

  // onEdit trigger
  ScriptApp.newTrigger("onEdit")
    .forSpreadsheet(SpreadsheetApp.getActive())
    .onEdit()
    .create();

  SpreadsheetApp.getUi().alert("✅ Auto-trigger enabled!\nAb naya lead add karo — sab kuch automatic hoga.");
}

// ── 8. Menu ──────────────────────────────────────────────────
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("🤖 AI CRM")
    .addItem("Setup Headers",           "setupHeaders")
    .addItem("Enable Auto-Trigger",     "setupTriggers")
    .addSeparator()
    .addItem("Process All New Leads",   "processAllLeads")
    .addSeparator()
    .addItem("Open CRM Dashboard",      "openDashboard")
    .addToUi();
}

function openDashboard() {
  const url = `${CRM_URL}/dashboard`;
  const html = HtmlService.createHtmlOutput(`<script>window.open('${url}');google.script.host.close();</script>`);
  SpreadsheetApp.getUi().showModalDialog(html, "Opening Dashboard...");
}
