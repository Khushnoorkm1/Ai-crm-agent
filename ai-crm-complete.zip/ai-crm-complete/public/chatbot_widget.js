<!-- ============================================================
  AI CRM Chatbot Widget
  Kisi bhi website ke </body> se pehle yeh paste karo
  CRM_URL ko apne server URL se replace karo
  ============================================================ -->
<script>
(function() {
  const CRM_URL   = "https://YOUR-SERVER-URL.com"; // ← apna URL
  const BOT_NAME  = "WebPro Assistant";             // ← apna naam
  const BOT_COLOR = "#185FA5";                      // ← apna color
  const POSITION  = "right";                        // left ya right

  // ── Session ID ──────────────────────────────────────────────
  let sessionId = localStorage.getItem("crm_chat_session");
  if (!sessionId) {
    sessionId = "chat_" + Date.now() + "_" + Math.random().toString(36).slice(2);
    localStorage.setItem("crm_chat_session", sessionId);
  }
  let isOpen = false, greeted = false;

  // ── Inject styles ───────────────────────────────────────────
  const style = document.createElement("style");
  style.textContent = `
    #crm-chat-btn {
      position:fixed; bottom:24px; ${POSITION}:24px; z-index:9999;
      width:56px; height:56px; border-radius:50%;
      background:${BOT_COLOR}; color:#fff; border:none; cursor:pointer;
      box-shadow:0 4px 16px rgba(0,0,0,.25); font-size:22px;
      display:flex; align-items:center; justify-content:center;
      transition:transform .2s;
    }
    #crm-chat-btn:hover { transform:scale(1.08); }
    #crm-chat-btn .notif {
      position:absolute; top:-4px; right:-4px;
      width:18px; height:18px; border-radius:50%;
      background:#E24B4A; color:#fff; font-size:10px; font-weight:700;
      display:flex; align-items:center; justify-content:center;
    }
    #crm-chat-box {
      position:fixed; bottom:92px; ${POSITION}:20px; z-index:9998;
      width:340px; height:480px;
      background:#fff; border-radius:16px;
      box-shadow:0 8px 32px rgba(0,0,0,.18);
      display:none; flex-direction:column; overflow:hidden;
      font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
      border:1px solid #e5e4de;
    }
    #crm-chat-box.open { display:flex; animation:slideUp .2s ease; }
    @keyframes slideUp { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
    .chat-header {
      background:${BOT_COLOR}; color:#fff;
      padding:14px 16px; display:flex; align-items:center; gap:10px;
    }
    .chat-avatar {
      width:36px; height:36px; border-radius:50%;
      background:rgba(255,255,255,.25);
      display:flex; align-items:center; justify-content:center; font-size:18px;
    }
    .chat-header-info { flex:1 }
    .chat-header-name { font-size:14px; font-weight:600 }
    .chat-header-status { font-size:11px; opacity:.8 }
    .chat-close { background:none; border:none; color:#fff; cursor:pointer; font-size:18px; opacity:.8 }
    .chat-close:hover { opacity:1 }
    .chat-messages {
      flex:1; overflow-y:auto; padding:12px; display:flex;
      flex-direction:column; gap:8px; background:#f8f7f4;
    }
    .chat-messages::-webkit-scrollbar { width:4px }
    .chat-messages::-webkit-scrollbar-thumb { background:#ddd; border-radius:2px }
    .msg { max-width:82%; padding:9px 12px; border-radius:12px; font-size:13px; line-height:1.5 }
    .msg.bot {
      background:#fff; color:#1a1a1a; border-radius:4px 12px 12px 12px;
      box-shadow:0 1px 3px rgba(0,0,0,.08); align-self:flex-start;
    }
    .msg.user {
      background:${BOT_COLOR}; color:#fff;
      border-radius:12px 4px 12px 12px; align-self:flex-end;
    }
    .msg.typing { background:#fff; align-self:flex-start; padding:12px }
    .typing-dots { display:flex; gap:4px }
    .typing-dots span {
      width:7px; height:7px; border-radius:50%; background:#aaa;
      animation:blink 1.2s infinite;
    }
    .typing-dots span:nth-child(2) { animation-delay:.2s }
    .typing-dots span:nth-child(3) { animation-delay:.4s }
    @keyframes blink { 0%,80%,100%{opacity:.3} 40%{opacity:1} }
    .chat-footer { padding:10px; background:#fff; border-top:1px solid #e5e4de; display:flex; gap:8px }
    .chat-input {
      flex:1; padding:9px 12px; font-size:13px; border:1px solid #e5e4de;
      border-radius:8px; outline:none; font-family:inherit;
    }
    .chat-input:focus { border-color:${BOT_COLOR} }
    .chat-send {
      width:38px; height:38px; border-radius:8px; background:${BOT_COLOR};
      color:#fff; border:none; cursor:pointer; font-size:16px;
      display:flex; align-items:center; justify-content:center;
    }
    .chat-send:hover { background:#0C447C }
    .chat-branding {
      text-align:center; font-size:10px; color:#aaa; padding:6px;
      background:#fff; border-top:1px solid #f0efe9;
    }
    .quick-replies { display:flex; flex-wrap:wrap; gap:6px; margin-top:4px }
    .quick-btn {
      padding:5px 10px; font-size:12px; border:1px solid ${BOT_COLOR};
      border-radius:20px; background:#fff; color:${BOT_COLOR};
      cursor:pointer; font-family:inherit;
    }
    .quick-btn:hover { background:${BOT_COLOR}; color:#fff }
    .lead-success {
      background:#EAF3DE; color:#27500A; padding:10px 12px;
      border-radius:8px; font-size:12px; text-align:center; margin:4px 0;
    }
  `;
  document.head.appendChild(style);

  // ── HTML ─────────────────────────────────────────────────────
  document.body.insertAdjacentHTML("beforeend", `
    <button id="crm-chat-btn" onclick="crmChatToggle()" title="Chat with us">
      💬
      <div class="notif" id="crm-notif" style="display:none">1</div>
    </button>
    <div id="crm-chat-box">
      <div class="chat-header">
        <div class="chat-avatar">🤖</div>
        <div class="chat-header-info">
          <div class="chat-header-name">${BOT_NAME}</div>
          <div class="chat-header-status">● Online — typically replies instantly</div>
        </div>
        <button class="chat-close" onclick="crmChatToggle()">✕</button>
      </div>
      <div class="chat-messages" id="crm-msgs"></div>
      <div class="chat-footer">
        <input class="chat-input" id="crm-input" placeholder="Apna message type karo..."
          onkeydown="if(event.key==='Enter')crmSend()">
        <button class="chat-send" onclick="crmSend()">➤</button>
      </div>
      <div class="chat-branding">Powered by AI CRM</div>
    </div>
  `);

  // ── Toggle chat ───────────────────────────────────────────────
  window.crmChatToggle = function() {
    isOpen = !isOpen;
    document.getElementById("crm-chat-box").classList.toggle("open", isOpen);
    document.getElementById("crm-chat-btn").innerHTML = isOpen
      ? "✕" : '💬<div class="notif" id="crm-notif" style="display:none">1</div>';
    if (isOpen && !greeted) { greeted = true; loadGreeting(); }
  };

  // ── Load greeting ─────────────────────────────────────────────
  async function loadGreeting() {
    showTyping();
    const resp = await fetch(`${CRM_URL}/api/chatbot/greet`, {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({ sessionId })
    }).catch(() => null);
    hideTyping();
    if (resp && resp.ok) {
      const data = await resp.json();
      addBotMsg(data.reply, data.quickReplies);
    } else {
      addBotMsg(`Namaste! 👋 Kya aap website banana chahte hain? Batao, main help karunga!`,
        ["Haan, interested hoon!", "Price kya hai?", "Pehle baat karni hai"]);
    }
  }

  // ── Send message ──────────────────────────────────────────────
  window.crmSend = async function(text) {
    const input = document.getElementById("crm-input");
    const msg   = text || input.value.trim();
    if (!msg) return;
    input.value = "";
    addUserMsg(msg);
    showTyping();

    try {
      const resp = await fetch(`${CRM_URL}/api/chatbot/message`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ sessionId, message: msg })
      });
      const data = await resp.json();
      hideTyping();
      addBotMsg(data.reply);
      if (data.leadCaptured) {
        addSuccessMsg("✅ Shukriya! Humara team aapko jaldi contact karega. 🎉");
      }
    } catch {
      hideTyping();
      addBotMsg("Sorry, network issue. Please thoda baad mein try karo.");
    }
  };

  // ── Helpers ───────────────────────────────────────────────────
  function addBotMsg(text, quickReplies) {
    const msgs = document.getElementById("crm-msgs");
    const div  = document.createElement("div");
    div.className = "msg bot";
    div.textContent = text;
    msgs.appendChild(div);
    if (quickReplies?.length) {
      const qr = document.createElement("div");
      qr.className = "quick-replies";
      quickReplies.forEach(q => {
        const btn = document.createElement("button");
        btn.className = "quick-btn"; btn.textContent = q;
        btn.onclick = () => window.crmSend(q);
        qr.appendChild(btn);
      });
      msgs.appendChild(qr);
    }
    msgs.scrollTop = msgs.scrollHeight;
  }

  function addUserMsg(text) {
    const msgs = document.getElementById("crm-msgs");
    const div  = document.createElement("div");
    div.className = "msg user"; div.textContent = text;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function addSuccessMsg(text) {
    const msgs = document.getElementById("crm-msgs");
    const div  = document.createElement("div");
    div.className = "lead-success"; div.textContent = text;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  }

  let typingEl = null;
  function showTyping() {
    const msgs = document.getElementById("crm-msgs");
    typingEl = document.createElement("div");
    typingEl.className = "msg typing";
    typingEl.innerHTML = '<div class="typing-dots"><span></span><span></span><span></span></div>';
    msgs.appendChild(typingEl);
    msgs.scrollTop = msgs.scrollHeight;
  }
  function hideTyping() { if (typingEl) { typingEl.remove(); typingEl = null; } }

  // Show notification bubble after 5 sec
  setTimeout(() => {
    if (!isOpen) {
      const n = document.getElementById("crm-notif");
      if (n) n.style.display = "flex";
    }
  }, 5000);
})();
</script>
