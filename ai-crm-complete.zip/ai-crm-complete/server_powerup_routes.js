// ============================================================
// server_powerups_addon.js
// Yeh routes FINAL_server.js mein add karo
// (server.listen ke upar paste karo)
// ============================================================

// ─────────────────────────────────────────────────────────────
// POWER-UP 1: TELEGRAM BOT ROUTES
// ─────────────────────────────────────────────────────────────
const { handleUpdate, setupWebhook, sendStartupNotification } = require("./services/telegramBot");

// Telegram webhook — Telegram yahan POST karta hai
app.post("/api/telegram/webhook", async (req, res) => {
  res.sendStatus(200); // Telegram ko pehle 200 do
  try {
    await handleUpdate(req.body, app.locals.db);
  } catch (err) {
    console.error("[Telegram] Handler error:", err.message);
  }
});

// Manual setup webhook (sirf ek baar chalana hai)
app.get("/api/telegram/setup", async (req, res) => {
  const result = await setupWebhook(process.env.BASE_URL);
  res.json(result);
});

// Test bot
app.post("/api/telegram/test", async (req, res) => {
  const { sendTelegram } = require("./services/telegramBot");
  await sendTelegram("✅ Test message! Bot is working 🤖");
  res.json({ success: true });
});

// ─────────────────────────────────────────────────────────────
// POWER-UP 2: CHATBOT ROUTES
// ─────────────────────────────────────────────────────────────
const { processMessage, getGreeting } = require("./services/chatbotService");

// Greeting — first message
app.post("/api/chatbot/greet", async (req, res) => {
  const { sessionId } = req.body;
  if (!sessionId) return res.status(400).json({ error: "sessionId required" });
  try {
    const reply = await getGreeting(sessionId);
    res.json({
      reply,
      quickReplies: ["Haan, interested hoon!", "Price kya hai?", "Pehle info chahiye"],
      sessionId,
    });
  } catch (err) {
    res.json({ reply: "Namaste! 👋 Website banana chahte hain? Batao, help karunga!", sessionId });
  }
});

// Main message handler
app.post("/api/chatbot/message", async (req, res) => {
  const { sessionId, message } = req.body;
  if (!sessionId || !message) return res.status(400).json({ error: "sessionId and message required" });
  try {
    const result = await processMessage(sessionId, message, app.locals.db);
    res.json(result);
  } catch (err) {
    console.error("[Chatbot] Error:", err.message);
    res.json({
      reply: "Sorry, thodi problem aa gayi! Hume directly call karo: " + (process.env.AGENCY_PHONE || ""),
      sessionId,
    });
  }
});

// Get session info (debug)
app.get("/api/chatbot/session/:sessionId", (req, res) => {
  const { getSession } = require("./services/chatbotService");
  res.json(getSession(req.params.sessionId));
});

// ─────────────────────────────────────────────────────────────
// STARTUP — in server.listen callback mein add karo
// ─────────────────────────────────────────────────────────────
// setupWebhook(process.env.BASE_URL);       // Telegram webhook register
// sendStartupNotification();                // Telegram pe "Server started" bhejo
