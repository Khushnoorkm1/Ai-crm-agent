// ============================================================
// services/callService.js  v2 — Conversational AI Calling
// Real 2-way conversation: Lead bolega → AI samjhega → jawab dega
// Twilio Media Streams + Claude = real voice AI agent
// ============================================================

const twilio    = require("twilio");
const Anthropic = require("@anthropic-ai/sdk");
const WebSocket = require("ws");
const fs        = require("fs");
const path      = require("path");

const client   = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
const ai       = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const RECORDINGS_DIR = "./recordings";
if (!fs.existsSync(RECORDINGS_DIR)) fs.mkdirSync(RECORDINGS_DIR);

// In-memory call sessions (callSid → session data)
const callSessions = new Map();

// ── Make conversational call ──────────────────────────────────
async function makeConversationalCall(lead, db) {
  return new Promise(async (resolve) => {
    try {
      const sessionId = `call_${lead.id}_${Date.now()}`;

      // Session initialize karo
      callSessions.set(sessionId, {
        lead,
        db,
        conversationHistory: [],
        outcome: null,
        recordingUrl: null,
        resolve,
        transcript: [],
      });

      // TwiML — Media Stream + recording both
      const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Connect>
    <Stream url="wss://${process.env.BASE_DOMAIN}/api/calling/stream/${sessionId}"/>
  </Connect>
  <Record
    action="${process.env.BASE_URL}/api/calling/recording-done/${sessionId}"
    recordingStatusCallback="${process.env.BASE_URL}/api/calling/recording-status"
    transcribe="true"
    transcribeCallback="${process.env.BASE_URL}/api/calling/transcription/${sessionId}"
    maxLength="300"
  />
</Response>`;

      const call = await client.calls.create({
        twiml,
        to:             "+91" + lead.phone.replace(/\D/g, "").slice(-10),
        from:           process.env.TWILIO_PHONE_NUMBER,
        statusCallback: `${process.env.BASE_URL}/api/calling/call-status/${sessionId}`,
        statusCallbackMethod: "POST",
        statusCallbackEvent: ["completed", "no-answer", "busy", "failed"],
      });

      callSessions.get(sessionId).callSid = call.sid;
      console.log(`📞 Conversational call started: ${lead.name} — SID: ${call.sid}`);

      // Timeout: 5 min baad auto-resolve
      setTimeout(() => {
        const session = callSessions.get(sessionId);
        if (session && !session.outcome) {
          session.outcome = "no_answer";
          resolve({ outcome: "no_answer", recordingUrl: null });
          callSessions.delete(sessionId);
        }
      }, 5 * 60 * 1000);

    } catch (err) {
      console.error("Call failed:", err.message);
      resolve({ outcome: "error", error: err.message });
    }
  });
}

// ── WebSocket handler — real-time audio stream ────────────────
// Yeh function Express app mein WebSocket route pe laga do
function handleMediaStream(ws, sessionId) {
  const session = callSessions.get(sessionId);
  if (!session) { ws.close(); return; }

  let streamSid = null;
  let audioBuffer = [];

  // Opening message — AI greet karega
  ws.on("open", () => {
    sendAIGreeting(ws, session, streamSid);
  });

  ws.on("message", async (data) => {
    const msg = JSON.parse(data);

    if (msg.event === "start") {
      streamSid = msg.start.streamSid;
      session.streamSid = streamSid;
      // Greet karo
      await sendAIGreeting(ws, session, streamSid);
    }

    if (msg.event === "media") {
      // Audio data collect karo
      audioBuffer.push(msg.media.payload);
    }

    if (msg.event === "stop") {
      // Call ended
      finalizeCall(session, ws);
    }
  });

  ws.on("close", () => {
    if (!session.outcome) session.outcome = "completed";
  });
}

// ── AI greeting ───────────────────────────────────────────────
async function sendAIGreeting(ws, session, streamSid) {
  const { lead } = session;
  const greeting = await generateAIResponse(session, null, "greeting");
  session.transcript.push({ role: "assistant", text: greeting });
  speakOnCall(ws, streamSid, greeting);
}

// ── Generate AI response using Claude ─────────────────────────
async function generateAIResponse(session, userSpeech, stage = "conversation") {
  const { lead } = session;

  const systemPrompt = `You are an AI sales agent for ${process.env.AGENCY_NAME || "WebPro Agency"} calling ${lead.name} from ${lead.business}.

Your goal: Convince them to get a professional website and book a Google Meet demo.

Rules:
- Speak in Hinglish (Hindi + English mix) — natural conversational tone
- Keep each response SHORT — max 2-3 sentences
- Be friendly, not pushy
- Listen to their concerns and address them
- If they say YES/interested → say you'll send meeting invite and say goodbye
- If they say NO/not interested → thank them and say goodbye  
- If they say LATER → ask when to call back and say goodbye
- IMPORTANT: After your response, on a NEW LINE write exactly one of:
  OUTCOME:interested
  OUTCOME:not_interested  
  OUTCOME:call_later
  OUTCOME:continuing
  (Only write interested/not_interested/call_later when the call should END)

Business context:
- Lead: ${lead.name}, Business: ${lead.business}, City: ${lead.city || "India"}
- We build websites starting ₹8,000, include Google ranking, 1 year support
- Free 15-min Google Meet demo available`;

  const messages = [
    ...session.conversationHistory,
    ...(userSpeech ? [{ role: "user", content: userSpeech }] : []),
  ];

  if (stage === "greeting") {
    messages.push({ role: "user", content: "START_GREETING" });
  }

  const response = await ai.messages.create({
    model:      "claude-sonnet-4-20250514",
    max_tokens: 200,
    system:     systemPrompt,
    messages:   messages.length > 0 ? messages : [{ role: "user", content: "START_GREETING" }],
  });

  const fullText  = response.content[0].text;
  const lines     = fullText.split("\n").filter(l => l.trim());
  const outcomeL  = lines.find(l => l.startsWith("OUTCOME:"));
  const spokenText = lines.filter(l => !l.startsWith("OUTCOME:")).join(" ").trim();

  // Extract outcome
  if (outcomeL) {
    const outcome = outcomeL.replace("OUTCOME:", "").trim();
    if (outcome !== "continuing") {
      session.outcome = outcome;
    }
  }

  // Update history
  if (userSpeech) session.conversationHistory.push({ role: "user", content: userSpeech });
  session.conversationHistory.push({ role: "assistant", content: spokenText });

  return spokenText;
}

// ── Text to speech on call (Twilio TTS) ───────────────────────
function speakOnCall(ws, streamSid, text) {
  if (!ws || !streamSid) return;
  // Twilio Media Stream ke liye TTS inject
  const ttsPayload = {
    event: "media",
    streamSid,
    media: {
      payload: Buffer.from(text).toString("base64"),
    },
  };
  ws.send(JSON.stringify({
    event: "sendText",
    streamSid,
    text,
    voice: "Polly.Aditi",
    language: "hi-IN",
  }));
}

// ── Handle incoming speech from lead ─────────────────────────
// Yeh Twilio Gather/Speech recognition se call hoga
async function handleLeadSpeech(sessionId, speechText, ws) {
  const session = callSessions.get(sessionId);
  if (!session) return;

  console.log(`[CALL][${session.lead.name}] Lead said: "${speechText}"`);
  session.transcript.push({ role: "user", text: speechText });

  const aiReply = await generateAIResponse(session, speechText);
  console.log(`[CALL][${session.lead.name}] AI said: "${aiReply}"`);
  session.transcript.push({ role: "assistant", text: aiReply });

  speakOnCall(ws, session.streamSid, aiReply);

  // Agar outcome determine ho gaya to call end karo
  if (session.outcome && session.outcome !== "continuing") {
    setTimeout(() => {
      if (ws) ws.close();
      finalizeCall(session, ws);
    }, 3000);
  }
}

// ── Finalize call — save everything ──────────────────────────
function finalizeCall(session, ws) {
  const { lead, db, outcome, transcript, resolve, recordingUrl } = session;
  const finalOutcome = outcome || "completed";

  // Save transcript to DB
  const data = db.read();
  if (!data.transcripts) data.transcripts = {};
  data.transcripts[lead.id] = {
    leadName: lead.name,
    phone:    lead.phone,
    outcome:  finalOutcome,
    transcript,
    time:     new Date().toISOString(),
  };

  // Lead status update
  const idx = data.leads.findIndex(l => l.id === lead.id);
  if (idx >= 0) {
    data.leads[idx].callOutcome   = finalOutcome;
    data.leads[idx].callTranscript = transcript;
    data.leads[idx].recordingUrl  = recordingUrl;
    data.leads[idx].lastContact   = new Date().toLocaleDateString("hi-IN");
  }
  db.write(data);

  resolve({ outcome: finalOutcome, recordingUrl, transcript });
  callSessions.delete(lead.id);
}

// ── Save recording ────────────────────────────────────────────
async function saveRecording(recordingUrl, recordingSid, sessionId, db) {
  const session = callSessions.get(sessionId);
  const https   = require("https");
  const filename = `${sessionId}_${recordingSid}.mp3`;
  const filepath = path.join(RECORDINGS_DIR, filename);

  return new Promise((resolve) => {
    const file    = fs.createWriteStream(filepath);
    const authUrl = recordingUrl.replace("https://",
      `https://${process.env.TWILIO_ACCOUNT_SID}:${process.env.TWILIO_AUTH_TOKEN}@`);

    https.get(authUrl + ".mp3", res => {
      res.pipe(file);
      file.on("finish", () => {
        file.close();
        const publicUrl = `${process.env.BASE_URL}/recordings/${filename}`;
        if (session) session.recordingUrl = publicUrl;

        // DB save
        const data = db.read();
        if (!data.recordings) data.recordings = [];
        data.recordings.unshift({
          sessionId, recordingSid, filename,
          url:  publicUrl,
          path: filepath,
          time: new Date().toISOString(),
        });
        db.write(data);
        resolve({ success: true, url: publicUrl });
      });
    }).on("error", err => resolve({ success: false, error: err.message }));
  });
}

module.exports = { makeConversationalCall, handleMediaStream, handleLeadSpeech, saveRecording, callSessions };
