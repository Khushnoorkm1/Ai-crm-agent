// ============================================================
// services/chatbotService.js
// POWER-UP 2: Website Chatbot — Visitor ka number lo → CRM mein daalo
// Visitor website pe aaye → Chat bot greet kare → Details lo
// → Auto CRM mein add → Automation start
// ============================================================

const Anthropic = require("@anthropic-ai/sdk");
const ai = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// In-memory chat sessions
const chatSessions = new Map();

// ── Create or get session ─────────────────────────────────────
function getSession(sessionId) {
  if (!chatSessions.has(sessionId)) {
    chatSessions.set(sessionId, {
      id:       sessionId,
      stage:    "greeting",       // greeting → name → phone → email → qualify → done
      lead:     {},
      history:  [],
      createdAt: new Date().toISOString(),
    });
  }
  return chatSessions.get(sessionId);
}

// ── Process message and return AI reply ───────────────────────
async function processMessage(sessionId, userMessage, db) {
  const session = getSession(sessionId);
  session.history.push({ role: "user", content: userMessage });

  const systemPrompt = `You are a friendly website chat assistant for ${process.env.AGENCY_NAME || "WebPro Agency"}, a website design company in India.

Your goal: Collect visitor's details (name, business, phone, email) naturally and qualify them as a lead.

Current stage: ${session.stage}
Collected so far: ${JSON.stringify(session.lead)}

Conversation rules:
- Speak in Hinglish (Hindi + English mix) — casual and friendly
- Keep messages SHORT (1-3 lines max)
- Guide conversation to collect: Name → Business name → Phone → Email
- Ask ONE thing at a time
- If they ask about pricing: "Starting ₹8,000 se! Aapke business ke liye free consultation de sakte hain 😊"
- If they ask about services: "Website design, Google ranking, online store — sab kuch! Kya aapka koi business hai?"
- When you have name + phone: say you'll have someone reach out and end politely

After your response, on a NEW LINE write:
STAGE:<next_stage>
EXTRACTED_NAME:<name or empty>
EXTRACTED_PHONE:<10-digit phone or empty>
EXTRACTED_EMAIL:<email or empty>
EXTRACTED_BUSINESS:<business name or empty>
READY:<true if name+phone collected, else false>

Stages: greeting → collecting_name → collecting_phone → collecting_email → qualifying → done`;

  const response = await ai.messages.create({
    model:      "claude-sonnet-4-20250514",
    max_tokens: 300,
    system:     systemPrompt,
    messages:   session.history,
  });

  const fullText  = response.content[0].text;
  const lines     = fullText.split("\n");
  const metaStart = lines.findIndex(l => l.startsWith("STAGE:"));

  // Extract spoken reply
  const reply = (metaStart > 0 ? lines.slice(0, metaStart) : lines)
    .join("\n").trim();

  // Parse metadata
  const getMeta = (key) => {
    const line = lines.find(l => l.startsWith(`${key}:`));
    return line ? line.replace(`${key}:`, "").trim() : "";
  };

  const stage    = getMeta("STAGE")            || session.stage;
  const name     = getMeta("EXTRACTED_NAME")   || session.lead.name;
  const phone    = getMeta("EXTRACTED_PHONE")  || session.lead.phone;
  const email    = getMeta("EXTRACTED_EMAIL")  || session.lead.email;
  const business = getMeta("EXTRACTED_BUSINESS") || session.lead.business;
  const ready    = getMeta("READY") === "true";

  // Update session
  session.stage         = stage;
  session.lead.name     = name     || session.lead.name;
  session.lead.phone    = phone    || session.lead.phone;
  session.lead.email    = email    || session.lead.email;
  session.lead.business = business || session.lead.business;
  session.history.push({ role: "assistant", content: reply });

  // If enough info collected → add to CRM
  if (ready && session.lead.name && session.lead.phone && !session.lead.addedToCRM) {
    session.lead.addedToCRM = true;
    await addLeadToCRM(session.lead, db);
  }

  return {
    reply,
    stage,
    leadCaptured: session.lead.addedToCRM || false,
    sessionId,
  };
}

// ── Add captured lead to CRM ──────────────────────────────────
async function addLeadToCRM(lead, db) {
  const newLead = {
    id:          `chat_${Date.now()}`,
    name:        lead.name,
    business:    lead.business  || "",
    phone:       String(lead.phone).replace(/\D/g,"").slice(-10),
    email:       lead.email     || "",
    city:        lead.city      || "",
    notes:       "Via website chatbot",
    source:      "chatbot",
    status:      "new",
    createdAt:   new Date().toISOString(),
    rowIndex:    null,
  };

  const data = db.read();
  data.leads.push(newLead);
  db.write(data);

  console.log(`[Chatbot] New lead captured: ${newLead.name} (${newLead.phone})`);

  // Telegram notification
  const { notify } = require("./telegramBot");
  await notify(`🆕 <b>New chatbot lead!</b>\n👤 ${newLead.name}\n📱 ${newLead.phone}\n🏢 ${newLead.business || "—"}\n\nAutomation starting...`);

  // Start automation
  const { processLeadAutomatically } = require("./autoOrchestrator");
  setImmediate(() => processLeadAutomatically(newLead, db));

  return newLead;
}

// ── Get greeting message ──────────────────────────────────────
async function getGreeting(sessionId) {
  const session = getSession(sessionId);
  const greetings = [
    `Namaste! 👋 Main ${process.env.AGENCY_NAME || "WebPro Agency"} ka assistant hoon.\n\nKya aap apne business ke liye website banana chahte hain? 😊`,
    `Hi! 👋 ${process.env.AGENCY_NAME || "WebPro Agency"} mein aapka swagat hai!\n\nKya main aapki help kar sakta hoon? 🚀`,
    `Namaste! 🙏 Professional website chahiye? Hum help kar sakte hain!\n\nAapka kya business hai? 💼`,
  ];
  const reply = greetings[Math.floor(Math.random() * greetings.length)];
  session.history.push({ role: "assistant", content: reply });
  return reply;
}

module.exports = { processMessage, getGreeting, getSession };
