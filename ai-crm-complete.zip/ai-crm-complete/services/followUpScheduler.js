// ============================================================
// services/followUpScheduler.js
// Automatic follow-up sequences — din ke hisaab se
// Day 0: Email + Call
// Day 3: Follow-up email + WhatsApp
// Day 7: Final call attempt
// Day 14: Last WhatsApp + mark as cold
// ============================================================

const { sendEmail, sendFollowUp } = require("./emailService");
const { makeConversationalCall }  = require("./callService");
const { sendWhatsApp }            = require("./whatsappService");
const { updateGoogleSheet }       = require("./sheetUpdateService");

// Pending follow-ups queue (in memory + persisted in DB)
const pendingFollowUps = new Map();

// ── Schedule a follow-up ──────────────────────────────────────
function scheduleFollowUp(lead, db, type, delayMs) {
  const key = `${lead.id}_${type}`;

  // Cancel existing
  if (pendingFollowUps.has(key)) {
    clearTimeout(pendingFollowUps.get(key).timer);
  }

  const scheduledAt = new Date(Date.now() + delayMs).toISOString();

  // Save to DB
  const data = db.read();
  if (!data.scheduledFollowUps) data.scheduledFollowUps = [];
  data.scheduledFollowUps.push({
    key, leadId: lead.id, leadName: lead.name,
    type, scheduledAt, status: "pending",
  });
  db.write(data);

  const timer = setTimeout(() => {
    executeFollowUp(lead, db, type);
    pendingFollowUps.delete(key);
  }, delayMs);

  pendingFollowUps.set(key, { timer, scheduledAt, type });
  console.log(`[Scheduler] ${lead.name} — ${type} scheduled at ${scheduledAt}`);
}

// ── Execute a follow-up ───────────────────────────────────────
async function executeFollowUp(lead, db, type) {
  // Fresh lead data lo
  const data  = db.read();
  const fresh = data.leads.find(l => l.id === lead.id);
  if (!fresh) return;

  // Agar already closed ya meeting — skip
  if (["closed", "meeting"].includes(fresh.status)) {
    console.log(`[Scheduler] Skip ${fresh.name} — already ${fresh.status}`);
    markFollowUpDone(lead.id, type, db);
    return;
  }

  console.log(`[Scheduler] Executing ${type} for ${fresh.name}`);

  switch (type) {
    case "day3_email":
      const emailResult = await sendFollowUp(fresh);
      await updateGoogleSheet(fresh.rowIndex, {
        status:    "Follow-up Sent",
        emailSent: `Follow-up: ${new Date().toLocaleString("hi-IN")}`,
      });
      // Schedule day 3 WhatsApp
      scheduleFollowUp(fresh, db, "day3_whatsapp", 2 * 60 * 60 * 1000); // 2 hr baad
      break;

    case "day3_whatsapp":
      await sendWhatsApp(fresh, "call_later");
      await updateGoogleSheet(fresh.rowIndex, {
        whatsappSent: new Date().toLocaleString("hi-IN"),
      });
      // Schedule day 7 call
      scheduleFollowUp(fresh, db, "day7_call", 4 * 24 * 60 * 60 * 1000); // 4 din baad
      break;

    case "day7_call":
      const callResult = await makeConversationalCall(fresh, db);
      await updateGoogleSheet(fresh.rowIndex, {
        callStatus:   callResult.outcome === "no_answer" ? "No Answer (D7)" : "Called (D7)",
        callResponse: callResult.outcome,
      });
      if (callResult.outcome === "not_interested") {
        await updateGoogleSheet(fresh.rowIndex, { status: "Closed" });
      } else {
        // Last attempt
        scheduleFollowUp(fresh, db, "day14_final", 7 * 24 * 60 * 60 * 1000);
      }
      break;

    case "day14_final":
      await sendWhatsApp(fresh, "final_attempt");
      const data2  = db.read();
      const lead14 = data2.leads.find(l => l.id === fresh.id);
      if (lead14 && lead14.status !== "interested" && lead14.status !== "meeting") {
        lead14.status = "cold";
        db.write(data2);
        await updateGoogleSheet(fresh.rowIndex, { status: "Cold" });
      }
      break;
  }

  markFollowUpDone(lead.id, type, db);
}

// ── Restore scheduled follow-ups on server restart ───────────
function restoreScheduledFollowUps(db) {
  const data = db.read();
  if (!data.scheduledFollowUps) return;

  const now = Date.now();
  data.scheduledFollowUps
    .filter(f => f.status === "pending")
    .forEach(f => {
      const lead = data.leads.find(l => l.id === f.leadId);
      if (!lead) return;

      const remaining = new Date(f.scheduledAt).getTime() - now;
      if (remaining <= 0) {
        // Overdue — run immediately
        executeFollowUp(lead, db, f.type);
      } else {
        // Re-schedule
        scheduleFollowUp(lead, db, f.type, remaining);
      }
    });

  console.log(`[Scheduler] Restored ${data.scheduledFollowUps.filter(f => f.status === "pending").length} follow-ups`);
}

function markFollowUpDone(leadId, type, db) {
  const data = db.read();
  if (!data.scheduledFollowUps) return;
  const item = data.scheduledFollowUps.find(f => f.leadId === leadId && f.type === type);
  if (item) item.status = "done";
  db.write(data);
}

// ── Get pending follow-ups list ───────────────────────────────
function getPendingFollowUps(db) {
  const data = db.read();
  return (data.scheduledFollowUps || []).filter(f => f.status === "pending");
}

module.exports = { scheduleFollowUp, executeFollowUp, restoreScheduledFollowUps, getPendingFollowUps };
