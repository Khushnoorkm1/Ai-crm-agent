// ============================================================
// services/leadScoringService.js
// AI se lead ko 0-100 score deta hai — priority decide karta hai
// High score = pehle call karo
// ============================================================

const Anthropic = require("@anthropic-ai/sdk");
const ai = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ── Rule-based pre-scoring (fast, no API call) ───────────────
function ruleBasedScore(lead) {
  let score = 50; // base
  const tags = [];

  const biz   = (lead.business || "").toLowerCase();
  const notes = (lead.notes    || "").toLowerCase();
  const city  = (lead.city     || "").toLowerCase();

  // Business type bonuses
  const highValue = ["restaurant","hotel","boutique","salon","clinic","hospital","school","academy","gym","spa","jewel","jewelry"];
  const midValue  = ["shop","store","mart","electronics","pharmacy","medical","travel","tours"];
  const lowValue  = ["kirana","general","misc","other"];

  if (highValue.some(k => biz.includes(k)))      { score += 25; tags.push("High-value business"); }
  else if (midValue.some(k => biz.includes(k)))  { score += 10; tags.push("Mid-value business"); }
  else if (lowValue.some(k => biz.includes(k)))  { score -= 10; tags.push("Low-margin business"); }

  // City tier
  const tier1 = ["mumbai","delhi","bangalore","bengaluru","hyderabad","chennai","pune","kolkata"];
  const tier2 = ["jaipur","ahmedabad","surat","lucknow","chandigarh","indore","kochi","bhopal"];
  if (tier1.some(c => city.includes(c)))         { score += 15; tags.push("Metro city"); }
  else if (tier2.some(c => city.includes(c)))    { score += 8;  tags.push("Tier-2 city"); }

  // Notes signals
  if (notes.includes("interested"))              { score += 20; tags.push("Already interested"); }
  if (notes.includes("website"))                 { score += 15; tags.push("Mentioned website"); }
  if (notes.includes("competitor"))              { score += 10; tags.push("Aware of competition"); }
  if (notes.includes("no budget") || notes.includes("nahi"))  { score -= 20; tags.push("Budget concern"); }

  // Has email = more likely legit
  if (lead.email && lead.email.includes("@") && !lead.email.includes("gmail")) {
    score += 10; tags.push("Business email");
  }

  return { score: Math.min(100, Math.max(0, score)), tags };
}

// ── AI-enhanced scoring ───────────────────────────────────────
async function generateLeadScore(lead) {
  // Start with rule-based
  const { score: ruleScore, tags: ruleTags } = ruleBasedScore(lead);

  try {
    // AI se additional insights
    const msg = await ai.messages.create({
      model:      "claude-sonnet-4-20250514",
      max_tokens: 150,
      messages: [{
        role:    "user",
        content: `Score this lead for website design services (India market).
Lead: Name: ${lead.name}, Business: ${lead.business}, City: ${lead.city || "?"}, Notes: ${lead.notes || "none"}
Rule score so far: ${ruleScore}/100

Respond with JSON only:
{"adjustment": <number -20 to +20>, "reason": "<one short reason>", "priority": "<HIGH/MEDIUM/LOW>"}`,
      }],
    });

    const text = msg.content[0].text.trim();
    const json = JSON.parse(text.replace(/```json|```/g, "").trim());

    const finalScore = Math.min(100, Math.max(0, ruleScore + (json.adjustment || 0)));
    const allTags    = [...ruleTags, json.reason].filter(Boolean);

    return {
      total:    finalScore,
      tags:     allTags,
      priority: json.priority || (finalScore >= 70 ? "HIGH" : finalScore >= 40 ? "MEDIUM" : "LOW"),
      ruleScore,
    };
  } catch {
    // Fallback to rule-based only
    return {
      total:    ruleScore,
      tags:     ruleTags,
      priority: ruleScore >= 70 ? "HIGH" : ruleScore >= 40 ? "MEDIUM" : "LOW",
      ruleScore,
    };
  }
}

// ── Sort leads by score ───────────────────────────────────────
function rankLeads(leads) {
  return [...leads].sort((a, b) => (b.score || 0) - (a.score || 0));
}

module.exports = { generateLeadScore, ruleBasedScore, rankLeads };
