// ============================================================
// services/retryService.js
// FIX 6 — Error Retry Logic
// Email fail ho → 3 baar try karo (exponential backoff)
// Call fail ho → 2 baar retry karo
// Sab failures DB mein log hote hain
// ============================================================

// ── Exponential backoff retry wrapper ─────────────────────────
// fn       = async function to retry
// options  = { maxRetries, baseDelayMs, label, onFailure }
async function withRetry(fn, options = {}) {
  const {
    maxRetries  = 3,
    baseDelayMs = 5000,   // 5 sec base, doubles each time
    label       = "operation",
    onFailure   = null,   // callback jab sab retries fail hojayein
  } = options;

  let lastError;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const result = await fn();
      if (attempt > 1) console.log(`[Retry] ${label} succeeded on attempt ${attempt}`);
      return { success: true, result, attempts: attempt };
    } catch (err) {
      lastError = err;
      console.warn(`[Retry] ${label} failed (attempt ${attempt}/${maxRetries}): ${err.message}`);

      if (attempt < maxRetries) {
        const delay = baseDelayMs * Math.pow(2, attempt - 1); // 5s, 10s, 20s
        console.log(`[Retry] Waiting ${delay/1000}s before retry...`);
        await new Promise(r => setTimeout(r, delay));
      }
    }
  }

  console.error(`[Retry] ${label} FAILED after ${maxRetries} attempts: ${lastError?.message}`);
  if (onFailure) await onFailure(lastError);
  return { success: false, error: lastError?.message, attempts: maxRetries };
}

// ── Email with retry ──────────────────────────────────────────
async function sendEmailWithRetry(lead, db, type = "cold") {
  const { sendEmail } = require("./emailService");

  const result = await withRetry(
    () => sendEmail(lead, type),
    {
      maxRetries:  3,
      baseDelayMs: 10000,   // 10s, 20s, 40s
      label:       `Email to ${lead.name}`,
      onFailure:   async (err) => {
        logFailure(lead, "email", err?.message || "Unknown", db);
        // Sheet mein failure note karo
        const { updateGoogleSheet } = require("./sheetUpdateService");
        await updateGoogleSheet(lead.rowIndex, { emailSent: "Failed — check logs", status: "Email Failed" });
      },
    }
  );

  if (result.success) {
    logSuccess(lead, "email", db);
  }
  return result;
}

// ── Call with retry ───────────────────────────────────────────
async function makeCallWithRetry(lead, db) {
  const { makeConversationalCall } = require("./callService");

  const result = await withRetry(
    () => makeConversationalCall(lead, db),
    {
      maxRetries:  2,
      baseDelayMs: 30000,   // 30s, 60s (Twilio rate limit aware)
      label:       `Call to ${lead.name}`,
      onFailure:   async (err) => {
        logFailure(lead, "call", err?.message || "Unknown", db);
        const { updateGoogleSheet } = require("./sheetUpdateService");
        await updateGoogleSheet(lead.rowIndex, { callStatus: "Failed — check logs" });
      },
    }
  );

  return result;
}

// ── WhatsApp with retry ───────────────────────────────────────
async function sendWhatsAppWithRetry(lead, db, outcome) {
  const { sendWhatsApp } = require("./whatsappService");

  return withRetry(
    () => sendWhatsApp(lead, outcome),
    {
      maxRetries:  3,
      baseDelayMs: 5000,
      label:       `WhatsApp to ${lead.name}`,
      onFailure:   (err) => logFailure(lead, "whatsapp", err?.message, db),
    }
  );
}

// ── Failure log ───────────────────────────────────────────────
function logFailure(lead, type, errorMsg, db) {
  const data = db.read();
  if (!data.failures) data.failures = [];
  data.failures.push({
    leadId:   lead.id,
    leadName: lead.name,
    phone:    lead.phone,
    type,
    error:    errorMsg,
    time:     new Date().toISOString(),
    retried:  true,
  });
  // Sirf last 200 failures rakho
  if (data.failures.length > 200) data.failures = data.failures.slice(-200);
  db.write(data);
  console.error(`[Failure] Logged: ${type} for ${lead.name} — ${errorMsg}`);
}

function logSuccess(lead, type, db) {
  const data = db.read();
  // Agar pehle fail tha, usse remove karo
  if (data.failures) {
    data.failures = data.failures.filter(
      f => !(f.leadId === lead.id && f.type === type)
    );
    db.write(data);
  }
}

// ── Get failure report ────────────────────────────────────────
function getFailures(db, limit = 50) {
  const data = db.read();
  return (data.failures || []).slice(-limit).reverse();
}

// ── Retry all pending failures ────────────────────────────────
async function retryAllFailures(db) {
  const failures = getFailures(db, 100);
  const unique   = [...new Map(failures.map(f => [f.leadId + f.type, f])).values()];
  console.log(`[Retry] Retrying ${unique.length} failed operations...`);

  for (const failure of unique) {
    const data = db.read();
    const lead = data.leads.find(l => l.id === failure.leadId);
    if (!lead) continue;

    if (failure.type === "email") await sendEmailWithRetry(lead, db);
    if (failure.type === "call")  await makeCallWithRetry(lead, db);
    if (failure.type === "whatsapp") await sendWhatsAppWithRetry(lead, db, "default");
    await new Promise(r => setTimeout(r, 2000));
  }
}

module.exports = {
  withRetry,
  sendEmailWithRetry,
  makeCallWithRetry,
  sendWhatsAppWithRetry,
  getFailures,
  retryAllFailures,
  logFailure,
};
