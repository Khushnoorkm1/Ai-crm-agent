// ============================================================
// services/telegramBot.js
// POWER-UP 1: Telegram Bot — Phone se poora CRM control karo
// Commands:
//   /start       — Welcome + menu
//   /stats       — Aaj ki stats
//   /leads       — Top 5 leads
//   /run         — Full automation start karo
//   /email       — Email campaign
//   /call        — Call campaign
//   /report      — Abhi report bhejo
//   /dnc <phone> — Number block karo
//   /failures    — Failed operations dekho
//   /retry       — Sab failures retry karo
//   /recordings  — Latest recordings
//   /help        — All commands
// ============================================================

const https = require("https");
const { buildStats } = require("./dailyReportService");

const BOT_TOKEN  = process.env.TELEGRAM_BOT_TOKEN;
const CHAT_ID    = process.env.TELEGRAM_CHAT_ID;    // tumhara personal chat ID
const BASE_URL   = `https://api.telegram.org/bot${BOT_TOKEN}`;

// ── Send message to Telegram ──────────────────────────────────
async function sendTelegram(text, chatId = CHAT_ID, opts = {}) {
  if (!BOT_TOKEN || !chatId) return;
  const body = JSON.stringify({
    chat_id:    chatId,
    text,
    parse_mode: "HTML",
    ...opts,
  });
  return new Promise((resolve) => {
    const req = https.request(`${BASE_URL}/sendMessage`, {
      method:  "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) },
    }, res => {
      let data = "";
      res.on("data", d => data += d);
      res.on("end", () => resolve(JSON.parse(data)));
    });
    req.on("error", err => { console.error("[Telegram] Send error:", err.message); resolve(null); });
    req.write(body);
    req.end();
  });
}

// ── Send notification (called from other services) ────────────
async function notify(message) {
  return sendTelegram(message);
}

// ── Inline keyboard buttons ───────────────────────────────────
function makeKeyboard(rows) {
  return { reply_markup: JSON.stringify({ inline_keyboard: rows }) };
}

// ── Handle incoming Telegram update ──────────────────────────
async function handleUpdate(update, db) {
  const msg      = update.message || update.callback_query?.message;
  const text     = update.message?.text || update.callback_query?.data || "";
  const chatId   = msg?.chat?.id;
  const username = msg?.chat?.username || msg?.chat?.first_name || "User";

  // Security: sirf tumhara chat ID accept karo
  if (CHAT_ID && String(chatId) !== String(CHAT_ID)) {
    return sendTelegram("⛔ Unauthorized access.", chatId);
  }

  const cmd = text.split(" ")[0].toLowerCase();
  const arg = text.split(" ").slice(1).join(" ").trim();

  console.log(`[Telegram] Command: ${cmd} from ${username}`);

  // ── Answer callback query (button press) ──────────────────
  if (update.callback_query) {
    await answerCallbackQuery(update.callback_query.id);
  }

  switch (cmd) {
    case "/start":
    case "/menu":
      return handleStart(chatId, username);

    case "/stats":
      return handleStats(chatId, db);

    case "/leads":
      return handleLeads(chatId, db, arg);

    case "/run":
    case "/run_all":
      return handleRunAll(chatId, db);

    case "/email":
      return handleEmailCampaign(chatId, db);

    case "/call":
      return handleCallCampaign(chatId, db);

    case "/report":
      return handleReport(chatId, db);

    case "/dnc":
      return handleDNC(chatId, arg, db);

    case "/dnc_list":
      return handleDNCList(chatId, db);

    case "/failures":
      return handleFailures(chatId, db);

    case "/retry":
      return handleRetry(chatId, db);

    case "/recordings":
      return handleRecordings(chatId, db);

    case "/pipeline":
      return handlePipeline(chatId, db);

    case "/help":
      return handleHelp(chatId);

    // Inline button callbacks
    case "run_all":    return handleRunAll(chatId, db);
    case "email_camp": return handleEmailCampaign(chatId, db);
    case "call_camp":  return handleCallCampaign(chatId, db);
    case "stats":      return handleStats(chatId, db);
    case "leads":      return handleLeads(chatId, db, "");
    case "report":     return handleReport(chatId, db);

    default:
      return sendTelegram(`❓ Unknown command. Type /help for all commands.`, chatId);
  }
}

// ── /start ────────────────────────────────────────────────────
async function handleStart(chatId, username) {
  const { isCallAllowed } = require("./guardService");
  const callStatus = isCallAllowed();

  const msg = `🤖 <b>AI CRM Bot</b>
Namaste ${username}! Main tumhara CRM assistant hoon.

📞 Calls: ${callStatus.allowed ? "✅ Active" : "🔴 Off-hours"} (${callStatus.currentIST})

Choose karo:`;

  return sendTelegram(msg, chatId, makeKeyboard([
    [{ text: "📊 Stats", callback_data: "stats" }, { text: "👥 Leads", callback_data: "leads" }],
    [{ text: "🚀 Run All", callback_data: "run_all" }, { text: "📧 Email", callback_data: "email_camp" }],
    [{ text: "📞 Calls", callback_data: "call_camp" }, { text: "📋 Report", callback_data: "report" }],
  ]));
}

// ── /stats ────────────────────────────────────────────────────
async function handleStats(chatId, db) {
  const data  = db.read();
  const stats = buildStats(data);
  const { isCallAllowed } = require("./guardService");
  const callCheck = isCallAllowed();

  const msg = `📊 <b>Today's Stats</b>

📞 Calls today:    <b>${stats.callsToday}</b>
📧 Emails today:   <b>${stats.emailsToday}</b>
🆕 New leads:      <b>${stats.newToday}</b>
🎯 Interested:     <b>${stats.interested}</b>
📅 Meetings:       <b>${stats.meetings}</b>
💰 Conversion:     <b>${stats.conversion}%</b>
⚠️ Failures:       <b>${stats.failures}</b>

📟 Total leads: <b>${stats.totalLeads}</b>
📞 Call status: ${callCheck.allowed ? "✅ Active" : `🔴 Off (${callCheck.currentIST})`}`;

  return sendTelegram(msg, chatId, makeKeyboard([
    [{ text: "🔄 Refresh", callback_data: "stats" }, { text: "📋 Full Report", callback_data: "report" }],
  ]));
}

// ── /leads ────────────────────────────────────────────────────
async function handleLeads(chatId, db, filter) {
  const data  = db.read();
  const leads = (data.leads || [])
    .filter(l => !filter || l.status === filter)
    .sort((a, b) => (b.score || 0) - (a.score || 0))
    .slice(0, 8);

  if (!leads.length) {
    return sendTelegram(`👥 No leads found${filter ? ` with status: ${filter}` : ""}.`, chatId);
  }

  const statusEmoji = { new:"🆕", contacted:"📞", interested:"🎯", meeting:"📅", closed:"✅", dnc:"🚫" };

  const msg = `👥 <b>Top Leads${filter ? ` (${filter})` : ""}</b>\n\n` +
    leads.map((l, i) => {
      const e = statusEmoji[l.status] || "•";
      const score = l.score ? ` [${l.score}/100]` : "";
      return `${i+1}. ${e} <b>${l.name}</b>${score}\n   📱 ${l.phone} | ${l.business || "—"}\n   📍 ${l.city || "—"} | ${l.status}`;
    }).join("\n\n");

  return sendTelegram(msg, chatId, makeKeyboard([
    [
      { text: "🆕 New",       callback_data: "leads_new" },
      { text: "🎯 Interested", callback_data: "leads_int" },
      { text: "📅 Meeting",   callback_data: "leads_meet" },
    ],
  ]));
}

// ── /run (full automation) ────────────────────────────────────
async function handleRunAll(chatId, db) {
  const data    = db.read();
  const targets = (data.leads || []).filter(l => !["closed","dnc","meeting"].includes(l.status));

  if (!targets.length) {
    return sendTelegram("✅ No pending leads to process.", chatId);
  }

  await sendTelegram(`🚀 <b>Starting full automation...</b>\n${targets.length} leads queued!\n\nEmail → Call → WhatsApp → Meeting\n\nMain update karta rahunga... 📲`, chatId);

  // Run async
  const { processLeadAutomatically } = require("./autoOrchestrator");
  let done = 0;
  (async () => {
    for (const lead of targets) {
      await processLeadAutomatically(lead, db);
      done++;
      if (done % 3 === 0) {
        await sendTelegram(`⏳ Progress: ${done}/${targets.length} leads processed`, chatId);
      }
      await new Promise(r => setTimeout(r, 35000));
    }
    await sendTelegram(`✅ <b>Automation complete!</b>\n${done} leads processed.\n\n/stats se results dekho`, chatId);
  })();

  return;
}

// ── /email ────────────────────────────────────────────────────
async function handleEmailCampaign(chatId, db) {
  const data    = db.read();
  const targets = (data.leads || []).filter(l => l.status === "new");
  await sendTelegram(`📧 <b>Email campaign starting...</b>\n${targets.length} new leads ko email bhej raha hoon`, chatId);

  const { sendEmailWithRetry } = require("./retryService");
  let sent = 0, failed = 0;
  for (const lead of targets) {
    const r = await sendEmailWithRetry(lead, db, "cold");
    r.success ? sent++ : failed++;
    await new Promise(r => setTimeout(r, 2000));
  }
  return sendTelegram(`📧 <b>Email Campaign Done!</b>\n✅ Sent: ${sent}\n❌ Failed: ${failed}`, chatId);
}

// ── /call ─────────────────────────────────────────────────────
async function handleCallCampaign(chatId, db) {
  const { isCallAllowed } = require("./guardService");
  const check = isCallAllowed();
  if (!check.allowed) {
    return sendTelegram(`🔴 <b>Calls blocked!</b>\n${check.reason}\n\nCalls resume at 10AM IST automatically.`, chatId);
  }
  const data    = db.read();
  const targets = (data.leads || []).filter(l => !["closed","dnc","meeting"].includes(l.status));
  await sendTelegram(`📞 <b>Call campaign starting...</b>\n${targets.length} leads ko call karunga\n\nHar call ke baad update aayega.`, chatId);

  const { makeConversationalCall } = require("./callService");
  for (const lead of targets) {
    await sendTelegram(`📞 Calling: <b>${lead.name}</b> (${lead.phone})`, chatId);
    const result = await makeConversationalCall(lead, db);
    const emoji  = result.outcome === "interested" ? "🎯" : result.outcome === "not_interested" ? "❌" : "🔄";
    await sendTelegram(`${emoji} <b>${lead.name}</b>: ${result.outcome}`, chatId);
    await new Promise(r => setTimeout(r, 35000));
  }
  return sendTelegram("✅ <b>Call campaign complete!</b>", chatId);
}

// ── /report ───────────────────────────────────────────────────
async function handleReport(chatId, db) {
  await sendTelegram("📋 Report generate ho raha hai...", chatId);
  const { sendDailyReport } = require("./dailyReportService");
  await sendDailyReport(db);
  return sendTelegram(`✅ <b>Report sent!</b>\nCheck your email inbox. 📧`, chatId);
}

// ── /dnc <phone> ──────────────────────────────────────────────
async function handleDNC(chatId, phone, db) {
  if (!phone) {
    return sendTelegram("Usage: <code>/dnc 9876543210</code>", chatId);
  }
  const { addToDNC } = require("./guardService");
  const data  = db.read();
  const lead  = data.leads.find(l => String(l.phone||"").slice(-10) === phone.replace(/\D/g,"").slice(-10));
  addToDNC({ name: lead?.name || phone, phone, email: lead?.email || "" }, "Blocked via Telegram");
  if (lead) { lead.status = "dnc"; db.write(data); }
  return sendTelegram(`🚫 <b>${lead?.name || phone}</b> blocked!\nWe will never contact them again.`, chatId);
}

// ── /dnc_list ─────────────────────────────────────────────────
async function handleDNCList(chatId, db) {
  const { getDNCList } = require("./guardService");
  const dnc = getDNCList();
  if (!dnc.numbers.length && !dnc.emails.length) {
    return sendTelegram("✅ DNC list is empty.", chatId);
  }
  const lines = dnc.numbers.map(n => `🚫 ${n.name || n.phone} — ${n.phone}`).join("\n");
  return sendTelegram(`<b>DNC List (${dnc.numbers.length} numbers)</b>\n\n${lines}`, chatId);
}

// ── /failures ─────────────────────────────────────────────────
async function handleFailures(chatId, db) {
  const { getFailures } = require("./retryService");
  const failures = getFailures(db, 10);
  if (!failures.length) {
    return sendTelegram("✅ No failures! Everything working fine.", chatId);
  }
  const lines = failures.slice(0, 8).map(f =>
    `❌ <b>${f.type}</b> — ${f.leadName}: ${f.error?.slice(0, 50)}`
  ).join("\n");
  return sendTelegram(`⚠️ <b>Recent Failures (${failures.length})</b>\n\n${lines}`, chatId,
    makeKeyboard([[{ text: "🔄 Retry All", callback_data: "retry_all" }]]));
}

// ── /retry ────────────────────────────────────────────────────
async function handleRetry(chatId, db) {
  await sendTelegram("🔄 Retrying all failed operations...", chatId);
  const { retryAllFailures } = require("./retryService");
  await retryAllFailures(db);
  return sendTelegram("✅ Retry complete! /failures se check karo.", chatId);
}

// ── /recordings ───────────────────────────────────────────────
async function handleRecordings(chatId, db) {
  const data = db.read();
  const recs = (data.recordings || []).slice(-5).reverse();
  if (!recs.length) return sendTelegram("🎙 No recordings yet.", chatId);

  const lines = recs.map((r, i) => {
    const dur = `${Math.floor((r.duration||0)/60)}:${String((r.duration||0)%60).padStart(2,"0")}`;
    return `${i+1}. <b>${r.leadName||"?"}</b> — ${dur}\n   🔗 <a href="${r.url}">Play Recording</a>`;
  }).join("\n\n");
  return sendTelegram(`🎙 <b>Latest Recordings</b>\n\n${lines}`, chatId);
}

// ── /pipeline ─────────────────────────────────────────────────
async function handlePipeline(chatId, db) {
  const data   = db.read();
  const leads  = data.leads || [];
  const counts = leads.reduce((a,l) => { a[l.status]=(a[l.status]||0)+1; return a; }, {});
  const bar    = (n, max) => "█".repeat(Math.round((n/Math.max(max,1))*10)) + "░".repeat(10-Math.round((n/Math.max(max,1))*10));
  const max    = Math.max(...Object.values(counts), 1);

  const msg = `📊 <b>Pipeline</b>

🆕 New:        ${bar(counts.new||0, max)} ${counts.new||0}
📞 Contacted:  ${bar(counts.contacted||0, max)} ${counts.contacted||0}
🎯 Interested: ${bar(counts.interested||0, max)} ${counts.interested||0}
📅 Meeting:    ${bar(counts.meeting||0, max)} ${counts.meeting||0}
✅ Closed:     ${bar(counts.closed||0, max)} ${counts.closed||0}
🚫 DNC:        ${bar(counts.dnc||0, max)} ${counts.dnc||0}

<b>Total: ${leads.length}</b>`;
  return sendTelegram(msg, chatId);
}

// ── /help ─────────────────────────────────────────────────────
async function handleHelp(chatId) {
  return sendTelegram(`🤖 <b>AI CRM Bot — All Commands</b>

<b>📊 Reports</b>
/stats      — Aaj ki stats
/pipeline   — Pipeline breakdown
/report     — Email report bhejo
/leads      — Top leads by score

<b>🚀 Campaigns</b>
/run        — Full automation (email+call+WA)
/email      — Sirf email campaign
/call       — Sirf call campaign
/retry      — Failed operations retry karo

<b>🚫 DNC</b>
/dnc 9876543210 — Number block karo
/dnc_list       — DNC list dekho

<b>⚠️ Monitoring</b>
/failures   — Recent failures dekho
/recordings — Latest call recordings

/menu — Main menu`, chatId);
}

// ── Callback query answer ─────────────────────────────────────
async function answerCallbackQuery(callbackQueryId) {
  const body = JSON.stringify({ callback_query_id: callbackQueryId });
  return new Promise(resolve => {
    const req = https.request(`${BASE_URL}/answerCallbackQuery`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) },
    }, res => { res.resume(); resolve(); });
    req.on("error", resolve);
    req.write(body);
    req.end();
  });
}

// ── Setup webhook (run once) ──────────────────────────────────
async function setupWebhook(baseUrl) {
  const webhookUrl = `${baseUrl}/api/telegram/webhook`;
  const body = JSON.stringify({ url: webhookUrl });
  return new Promise(resolve => {
    const req = https.request(`${BASE_URL}/setWebhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) },
    }, res => {
      let data = "";
      res.on("data", d => data += d);
      res.on("end", () => {
        const result = JSON.parse(data);
        if (result.ok) console.log(`[Telegram] ✅ Webhook set: ${webhookUrl}`);
        else console.error("[Telegram] Webhook failed:", result.description);
        resolve(result);
      });
    });
    req.on("error", resolve);
    req.write(body);
    req.end();
  });
}

// ── Startup notification ──────────────────────────────────────
async function sendStartupNotification() {
  if (!BOT_TOKEN || !CHAT_ID) return;
  await sendTelegram(`✅ <b>AI CRM Server Started!</b>\n\n/menu se sab kuch control karo 🎮`);
}

module.exports = { handleUpdate, notify, sendTelegram, setupWebhook, sendStartupNotification };
