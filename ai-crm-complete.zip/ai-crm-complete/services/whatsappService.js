// ============================================================
// services/whatsappService.js
// Twilio WhatsApp API se messages bhejta hai
// Call ke baad automatic WhatsApp — interested leads ko meeting link
// ============================================================

const twilio    = require("twilio");
const Anthropic = require("@anthropic-ai/sdk");

const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
const ai     = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ── Generate WhatsApp message using AI ───────────────────────
async function generateWhatsAppMessage(lead, callOutcome) {
  const scenarios = {
    interested:     `Lead just said YES on phone call. Send excited confirmation with meeting link placeholder [MEET_LINK]. Keep it short and warm.`,
    call_later:     `Lead said they'll think about it. Send a friendly reminder with our offer. Include website: ${process.env.AGENCY_WEBSITE || "#"}`,
    no_answer:      `We couldn't reach them on call. Introduce ourselves and mention website design offer. Ask if they'd like a callback.`,
    not_interested: `Lead wasn't interested on call. Send a polite goodbye with our portfolio link. Leave door open for future.`,
    default:        `Follow up after first email. Introduce our website design services. Friendly tone.`,
  };

  const context = scenarios[callOutcome] || scenarios.default;

  const msg = await ai.messages.create({
    model:      "claude-sonnet-4-20250514",
    max_tokens: 200,
    messages: [{
      role:    "user",
      content: `Write a short WhatsApp message in Hinglish for ${lead.name} (${lead.business}).
Context: ${context}
Agency: ${process.env.AGENCY_NAME || "WebPro Agency"}
Rules: Max 3 lines. Use 1-2 emojis. Conversational, not formal. No "Dear" or "Respected".
Return ONLY the message text, nothing else.`,
    }],
  });

  return msg.content[0].text.trim();
}

// ── Send WhatsApp message ─────────────────────────────────────
async function sendWhatsApp(lead, callOutcome = "default", meetingLink = null) {
  try {
    let messageText = await generateWhatsAppMessage(lead, callOutcome);

    // Meeting link inject karo agar available hai
    if (meetingLink) {
      messageText = messageText.replace("[MEET_LINK]", meetingLink);
    } else {
      messageText = messageText.replace("[MEET_LINK]", process.env.AGENCY_WEBSITE || "our website");
    }

    const message = await client.messages.create({
      from: `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER || process.env.TWILIO_PHONE_NUMBER}`,
      to:   `whatsapp:+91${lead.phone.replace(/\D/g, "").slice(-10)}`,
      body: messageText,
    });

    console.log(`💬 WhatsApp sent to ${lead.name}: ${message.sid}`);
    return { success: true, sid: message.sid, text: messageText };
  } catch (err) {
    console.error(`❌ WhatsApp failed for ${lead.name}:`, err.message);
    return { success: false, error: err.message };
  }
}

// ── Send WhatsApp with media (e.g. portfolio PDF) ─────────────
async function sendWhatsAppWithMedia(lead, mediaUrl, caption) {
  try {
    const message = await client.messages.create({
      from:    `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER}`,
      to:      `whatsapp:+91${lead.phone.replace(/\D/g, "").slice(-10)}`,
      body:    caption || `${lead.name} ji, hamara portfolio dekho! 🌐`,
      mediaUrl: [mediaUrl],
    });
    return { success: true, sid: message.sid };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ── Handle incoming WhatsApp reply ───────────────────────────
async function handleIncomingWhatsApp(from, body, db) {
  const phone = from.replace("whatsapp:+91", "").replace("whatsapp:+", "");
  const data  = db.read();
  const lead  = data.leads.find(l => l.phone.slice(-10) === phone.slice(-10));

  if (!lead) {
    console.log(`Unknown WhatsApp from ${from}: ${body}`);
    return;
  }

  console.log(`💬 WhatsApp reply from ${lead.name}: "${body}"`);

  // Save response
  lead.whatsappResponse  = body;
  lead.whatsappRepliedAt = new Date().toISOString();
  lead.lastContact       = new Date().toLocaleDateString("hi-IN");

  // AI se intent detect karo
  const intentMsg = await ai.messages.create({
    model:      "claude-sonnet-4-20250514",
    max_tokens: 50,
    messages: [{
      role:    "user",
      content: `Classify this WhatsApp reply intent in one word: "${body}"
Options: INTERESTED, NOT_INTERESTED, QUESTION, MEETING_CONFIRM, CALL_REQUEST, OTHER
Reply with just the one word.`,
    }],
  });

  const intent = intentMsg.content[0].text.trim().toUpperCase();
  console.log(`[WhatsApp Intent] ${lead.name}: ${intent}`);

  // Intent ke basis pe action lo
  if (intent === "INTERESTED" || intent === "MEETING_CONFIRM") {
    lead.status = "interested";
    // Auto-schedule meeting
    const { autoScheduleForInterestedLead } = require("./meetingService");
    await autoScheduleForInterestedLead(lead, db);
  } else if (intent === "NOT_INTERESTED") {
    lead.status = "closed";
  }

  // Update DB
  const idx = data.leads.findIndex(l => l.id === lead.id);
  if (idx >= 0) data.leads[idx] = lead;
  if (!data.whatsappReplies) data.whatsappReplies = [];
  data.whatsappReplies.push({
    leadId: lead.id, leadName: lead.name, phone,
    message: body, intent, time: new Date().toISOString(),
  });
  db.write(data);

  // Sheet update
  const { updateGoogleSheet } = require("./sheetUpdateService");
  await updateGoogleSheet(lead.rowIndex, {
    status: lead.status,
    notes:  `WhatsApp: "${body}" (${intent})`,
  });

  return intent;
}

module.exports = { sendWhatsApp, sendWhatsAppWithMedia, handleIncomingWhatsApp, generateWhatsAppMessage };
