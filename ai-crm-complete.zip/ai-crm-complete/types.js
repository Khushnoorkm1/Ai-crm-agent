// ============================================================
// types.js — JSDoc type definitions
// Yeh file import mat karo — sirf IDE IntelliSense ke liye hai
// VSCode, Cursor, Copilot — sab in types ko padh lete hain
// ============================================================

/**
 * @typedef {Object} Lead
 * @property {string} id - Unique ID: "lead_ROW_TIMESTAMP"
 * @property {string} name - Full name
 * @property {string} business - Business name
 * @property {string} phone - 10 digits, no +91 (e.g. "9876543210")
 * @property {string} email - Email address
 * @property {string} [city] - City name
 * @property {string} [notes] - Notes from Sheet column F
 * @property {"google_sheet"|"chatbot"|"manual"} [source] - Where lead came from
 * @property {"new"|"contacted"|"interested"|"meeting"|"closed"|"dnc"} status
 * @property {number} [score] - AI score 0-100
 * @property {"HIGH"|"MEDIUM"|"LOW"} [priority]
 * @property {string[]} [scoreTags] - Score reasoning tags
 * @property {number} [rowIndex] - Google Sheet row number (1-based)
 * @property {string} [emailSent] - ISO timestamp
 * @property {"interested"|"not_interested"|"call_later"|"no_answer"|"error"} [callOutcome]
 * @property {Array<{role:string,text:string}>} [callTranscript]
 * @property {number} [callDuration] - seconds
 * @property {string} [recordingFile] - filename in ./recordings/
 * @property {string} [whatsappSent] - ISO timestamp
 * @property {string} [meetLink] - Google Meet URL
 * @property {string} [meetingTime] - ISO timestamp
 * @property {string} [lastContact] - Human readable date
 * @property {string} createdAt - ISO timestamp
 */

/**
 * @typedef {Object} DB
 * @property {Lead[]} leads
 * @property {CallLog[]} calls
 * @property {EmailLog[]} emails
 * @property {Recording[]} recordings
 * @property {Meeting[]} meetings
 * @property {Object.<string, TranscriptEntry>} transcripts - keyed by sessionId
 * @property {Failure[]} failures
 * @property {Object.<string, LogEntry[]>} logs - keyed by leadId
 * @property {DNCList} dnc
 * @property {FollowUp[]} scheduledFollowUps
 * @property {ReportSent[]} reportsSent
 */

/**
 * @typedef {Object} DBInstance
 * @property {function(): DB} read - Always call fresh: const data = db.read()
 * @property {function(DB): void} write - Save changes: db.write(data)
 */

/**
 * @typedef {Object} CallLog
 * @property {string} leadId
 * @property {string} leadName
 * @property {string} phone
 * @property {string} status - Twilio call status
 * @property {string|number} duration - seconds
 * @property {string} time - ISO timestamp
 */

/**
 * @typedef {Object} EmailLog
 * @property {string} leadName
 * @property {string} email
 * @property {string} subject
 * @property {string} sentAt - ISO timestamp
 * @property {boolean} success
 */

/**
 * @typedef {Object} Recording
 * @property {string} sessionId
 * @property {string} recordingSid
 * @property {string} filename - e.g. "sessionId_sid.mp3"
 * @property {string} url - e.g. "/recordings/filename.mp3"
 * @property {string} path - local file path
 * @property {string} time - ISO timestamp
 * @property {number} [duration] - seconds
 * @property {string} [outcome] - call outcome
 */

/**
 * @typedef {Object} Meeting
 * @property {string} leadId
 * @property {string} leadName
 * @property {string} meetLink
 * @property {string} startTime - ISO timestamp
 * @property {string} scheduledAt - ISO timestamp
 */

/**
 * @typedef {Object} Failure
 * @property {string} leadId
 * @property {string} leadName
 * @property {string} phone
 * @property {"email"|"call"|"whatsapp"} type
 * @property {string} error
 * @property {string} time - ISO timestamp
 */

/**
 * @typedef {Object} DNCList
 * @property {Array<{phone:string, name:string, reason:string, addedAt:string}>} numbers
 * @property {Array<{email:string, name:string, reason:string, addedAt:string}>} emails
 */

/**
 * @typedef {Object} FollowUp
 * @property {string} key - "leadId_type"
 * @property {string} leadId
 * @property {string} leadName
 * @property {"day3_email"|"day3_whatsapp"|"day7_call"|"day14_final"} type
 * @property {string} scheduledAt - ISO timestamp
 * @property {"pending"|"done"} status
 */

/**
 * @typedef {Object} GuardResult
 * @property {boolean} blocked
 * @property {string} [reason]
 * @property {"dnc"|"duplicate"} [type]
 */

/**
 * @typedef {Object} CallResult
 * @property {"interested"|"not_interested"|"call_later"|"no_answer"|"error"|"completed"} outcome
 * @property {string|null} recordingUrl
 * @property {Array<{role:string,text:string}>} [transcript]
 */

/**
 * @typedef {Object} ScoreResult
 * @property {number} total - 0-100
 * @property {string[]} tags
 * @property {"HIGH"|"MEDIUM"|"LOW"} priority
 * @property {number} ruleScore
 */

/**
 * @typedef {Object} MeetingResult
 * @property {boolean} success
 * @property {string} [meetLink]
 * @property {string} [eventId]
 * @property {string} [startTime]
 * @property {string} [error]
 */

/**
 * @typedef {Object} RetryResult
 * @property {boolean} success
 * @property {any} [result]
 * @property {number} attempts
 * @property {string} [error]
 */

/**
 * @typedef {Object} ChatSession
 * @property {string} id - sessionId
 * @property {"greeting"|"collecting_name"|"collecting_phone"|"collecting_email"|"qualifying"|"done"} stage
 * @property {Partial<Lead>} lead - collected so far
 * @property {Array<{role:string,content:string}>} history
 * @property {string} createdAt
 * @property {boolean} [addedToCRM]
 */

/**
 * @typedef {Object} TelegramUpdate
 * @property {Object} [message]
 * @property {Object} [callback_query]
 */

/**
 * @typedef {Object} DashboardStats
 * @property {number} total
 * @property {Object.<string,number>} byStatus
 * @property {number[]} weekCalls - 7 elements, index 0=oldest day
 * @property {number} emailsSent
 * @property {number} callsMade
 * @property {number} meetings
 * @property {number} interested
 * @property {number} whatsAppSent
 * @property {number} recordings
 * @property {number} failures
 * @property {number} conversion - percentage 0-100
 * @property {any[]} recentActivity
 */

module.exports = {}; // Empty export — file is for types only
